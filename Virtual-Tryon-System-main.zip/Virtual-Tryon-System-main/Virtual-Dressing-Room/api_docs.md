# Virtual Dressing Room API Documentation

This document provides detailed information about the Virtual Dressing Room API endpoints and their usage.

## REST API Endpoints

### GET /

**Description:** Returns the main jewelry brand page.

**Response:** HTML page with the jewelry brand interface.

**Example:**
```
GET http://localhost:5001/
```

### GET /jewelry

**Description:** Returns the main jewelry brand page (same as root).

**Response:** HTML page with the jewelry brand interface.

**Example:**
```
GET http://localhost:5001/jewelry
```

### GET /jewelry_brand

**Description:** Returns the main jewelry brand page (alternate route).

**Response:** HTML page with the jewelry brand interface.

**Example:**
```
GET http://localhost:5001/jewelry_brand
```

### GET /original_index

**Description:** Returns the original index page with the catalog of items for try-on.

**Response:** HTML page with the item catalog.

**Example:**
```
GET http://localhost:5001/original_index
```

### GET /tryon/{file_path}

**Description:** Renders the checkout page for trying on a specific item.

**Parameters:**
- `file_path` (path parameter): Path to the item to try on, relative to the `static` directory.

**Response:** HTML page with webcam interface for virtual try-on.

**Example:**
```
GET http://localhost:5001/tryon/images/Necklace11.png
```

**Rate Limit:** 30 requests per minute

### GET /checkout

**Description:** Renders the checkout page.

**Response:** HTML page with the checkout interface.

**Example:**
```
GET http://localhost:5001/checkout
```

### POST /upload_frame

**Description:** Process a frame with virtual try-on using a REST approach.

**Parameters:**
- `frame` (multipart/form-data): Image file containing the frame to process
- `json_data` (form field): JSON string containing file_path information

**JSON Data Format:**
```json
{
  "file_path": "path/to/item.png"
}
```

**Response:** JSON object with processed image or error information.

**Success Response:**
```json
{
  "image": "base64_encoded_image_data"
}
```

**Error Response:**
```json
{
  "error": "Error message"
}
```

**Example:**
```
POST http://localhost:5001/upload_frame
Content-Type: multipart/form-data

frame=@webcam_frame.jpg
json_data={"file_path":"static/images/Necklace11.png"}
```

**Rate Limit:** 60 requests per minute

### GET /api/docs

**Description:** Returns API documentation.

**Response:** HTML page with API documentation.

**Example:**
```
GET http://localhost:5001/api/docs
```

## WebSocket API

The WebSocket API provides real-time communication for the virtual try-on experience, which is more efficient than the REST API approach.

### Connection

To establish a Socket.IO connection:

```javascript
const socket = io.connect(window.location.origin, {
  reconnection: true,
  reconnectionAttempts: 5
});
```

### Client Events

#### stream_frame

**Description:** Send a webcam frame to be processed with virtual try-on.

**Parameters:**
- `frame` (string): Base64-encoded image data (with or without the 'data:image/jpeg;base64,' prefix)
- `file_path` (string): Path to the item to try on, relative to the `static` directory

**Example:**
```javascript
socket.emit('stream_frame', {
  frame: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBD...',
  file_path: 'static/images/Necklace11.png'
});
```

### Server Events

#### processed_frame

**Description:** Receive a processed frame with the item overlay.
......
**Data Format:**
```javascript
{
  image: 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBD...'
}
```

**Example:**
```javascript
socket.on('processed_frame', (data) => {
  // Display the processed image
  const img = new Image();
  img.src = data.image;
  context.drawImage(img, 0, 0);
});
```

#### no_face

**Description:** Notification when no face is detected in the frame.

**Data Format:**
```javascript
{
  message: 'No face detected or no sprite applied'
}
```

**Example:**
```javascript
socket.on('no_face', (data) => {
  console.log(data.message);
  statusMessage.textContent = data.message;
});
```

#### stream_error

**Description:** Error information when processing the frame.

**Data Format:**
```javascript
{
  error: 'Error message'
}
```

**Example:**
```javascript
socket.on('stream_error', (data) => {
  console.error('Stream error:', data.error);
  statusMessage.textContent = `Error: ${data.error}`;
});
```

## Example Use Cases

### Access Main Jewelry Brand Page
```
GET http://localhost:5001/
```

### Try On a Necklace
```
GET http://localhost:5001/tryon/jewelry/Necklace11.png
```

### Try On Earrings
```
GET http://localhost:5001/tryon/jewelry/Earrings21.png
```

### Access Checkout Page
```
GET http://localhost:5001/checkout
```

## Error Codes

The API may return the following HTTP status codes:

- **200 OK**: Request successful
- **400 Bad Request**: Invalid input parameters
- **403 Forbidden**: Access denied (e.g., path traversal attempt)
- **404 Not Found**: Resource not found
- **429 Too Many Requests**: Rate limit exceeded
- **500 Internal Server Error**: Server error

## Security Considerations

- All file paths are sanitized to prevent directory traversal attacks
- Rate limiting is applied to prevent abuse
- Input validation is performed on all parameters
- Cross-Origin Resource Sharing (CORS) protection is in place 