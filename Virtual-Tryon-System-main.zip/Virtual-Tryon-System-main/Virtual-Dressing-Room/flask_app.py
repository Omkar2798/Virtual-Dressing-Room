from flask import Flask, render_template, Response, request, jsonify
from flask_socketio import SocketIO, emit
import base64
import numpy as np
import cv2
import json
import virtual_trial
import os
import logging
import re
from functools import wraps
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.utils import secure_filename
from typing import Dict, Any, Tuple, Optional, Union, List
from flask_cors import CORS
import time

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('virtual_dressing_room_app')

app = Flask(__name__)
# Enable CORS for all routes
CORS(app)

app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

# Setup rate limiting
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Configure SocketIO with CORS enabled
socketio = SocketIO(app, async_mode='eventlet', cors_allowed_origins="*")

# Add CORS headers to all responses
@app.after_request
def add_cors_headers(response):
    response.headers['Access-Control-Allow-Origin'] = '*'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type,Authorization'
    response.headers['Access-Control-Allow-Methods'] = 'GET,PUT,POST,DELETE,OPTIONS'
    response.headers['Content-Security-Policy'] = "default-src * 'unsafe-inline' 'unsafe-eval'; img-src * data: blob:;"
    return response

def allowed_file(filename: str) -> bool:
    """
    Check if a file has an allowed extension
    
    Args:
        filename: The filename to check
        
    Returns:
        True if file extension is allowed, False otherwise
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def secure_path(path: str) -> str:
    """
    Make a file path secure by removing path traversal characters
    
    Args:
        path: The path to secure
        
    Returns:
        Secured path string
    """
    if not path:
        return ""
        
    # Log original path for debugging
    logger.info(f"Securing path: {path}")
    
    # Replace backslashes with forward slashes
    path = path.replace('\\', '/')
    
    # Remove any path traversal attempts
    path = re.sub(r'\.\.', '', path)
    
    # Remove any double slashes
    path = re.sub(r'//+', '/', path)
    
    # Remove leading slash if present
    path = path.lstrip('/')
    
    # Remove "static/" prefix if it exists (since we add it back later)
    if path.startswith('static/'):
        path = path[7:]
        
    logger.info(f"Secured path: {path}")
    return path

@app.route('/tryon/<path:file_path>', methods=['POST', 'GET'])
@limiter.limit("30 per minute")
def tryon(file_path: str) -> Union[str, Tuple[str, int]]:
    """
    Render the checkout page for trying on a specific item
    
    Args:
        file_path: Path to the item to try on
        
    Returns:
        Rendered HTML template or error page
        
    Rate limit:
        30 requests per minute
    """
    try:
        # Add debug logging
        print(f"Received request for file_path: {file_path}")
        logger.info(f"Received request for file_path: {file_path}")
        
        if not file_path:
            logger.error("Empty file path provided")
            return render_template("error.html", error="Invalid file path provided"), 400
            
        # Sanitize file path to prevent directory traversal
        file_path = secure_path(file_path)
        
        # Debug logging
        print(f"Sanitized file_path: {file_path}")
        logger.info(f"Sanitized file_path: {file_path}")
        
        # Validate if the file exists in the allowed directory
        real_path = os.path.join('static', file_path)
        real_path = os.path.normpath(real_path)
        
        # More debug logging
        print(f"Real path: {real_path}")
        print(f"File exists: {os.path.exists(real_path)}")
        logger.info(f"Real path: {real_path}")
        logger.info(f"File exists: {os.path.exists(real_path)}")
        logger.info(f"Current working directory: {os.getcwd()}")
        
        # Ensure the path is still in the static directory
        static_dir = os.path.abspath(os.path.join(os.getcwd(), 'static'))
        real_abs_path = os.path.abspath(real_path)
        
        logger.info(f"Static directory: {static_dir}")
        logger.info(f"Absolute real path: {real_abs_path}")
        logger.info(f"Path in static directory: {real_abs_path.startswith(static_dir)}")
        
        if not real_abs_path.startswith(static_dir):
            logger.error(f"Path traversal attempt: {real_path}")
            return render_template("error.html", error="Invalid file path"), 403
            
        if not os.path.exists(real_path):
            logger.error(f"File not found: {real_path}")
            return render_template("error.html", error=f"File not found: {real_path}"), 404
            
        logger.info(f"Rendering checkout.html with file_path={file_path}")
        return render_template("checkout.html", file_path=file_path)
    except Exception as e:
        logger.error(f"Error in tryon route: {str(e)}")
        return render_template("error.html", error=f"An unexpected error occurred: {str(e)}"), 500

@app.route('/upload_frame', methods=['POST'])
@limiter.limit("60 per minute")
def process_frame_upload() -> Tuple[Dict[str, Any], int]:
    """
    Process a frame upload with a sprite overlay
    
    Expects:
        - 'frame': An image file
        - 'json_data': JSON string containing 'file_path'
        
    Returns:
        JSON response with processed image or error message
        
    Rate limit:
        60 requests per minute
    """
    try:
        # Validate input
        if 'frame' not in request.files:
            logger.error("No frame part in the request")
            return jsonify({'error': 'No frame part'}), 400
            
        if 'json_data' not in request.form:
            logger.error("No JSON data in the request")
            return jsonify({'error': 'No JSON data'}), 400
            
        file = request.files['frame']
        if not file:
            logger.error("Empty file uploaded")
            return jsonify({'error': 'Empty file'}), 400
            
        # Validate file type
        if file.filename and not allowed_file(file.filename):
            logger.error(f"Invalid file type: {file.filename}")
            return jsonify({'error': 'Invalid file type. Only PNG and JPEG allowed.'}), 400
            
        json_data = request.form['json_data']
        
        try:
            data = json.loads(json_data)
        except json.JSONDecodeError:
            logger.error("Invalid JSON data")
            return jsonify({'error': 'Invalid JSON data'}), 400
            
        if 'file_path' not in data:
            logger.error("No file_path in JSON data")
            return jsonify({'error': 'No file_path in data'}), 400
            
        file_path = data['file_path']
        
        # Secure the file path
        file_path = secure_path(file_path)
        
        # Validate file path
        real_path = os.path.join('static', file_path)
        real_path = os.path.normpath(real_path)
        
        # Ensure the path is still in the static directory
        if not real_path.startswith(os.path.join(os.getcwd(), 'static').replace('\\', '/')):
            logger.error(f"Path traversal attempt: {real_path}")
            return jsonify({'error': 'Invalid file path'}), 403
            
        if not os.path.exists(real_path):
            logger.error(f"File not found: {real_path}")
            return jsonify({'error': f'File not found: {file_path}'}), 404
        
        # Read the uploaded frame
        filestr = file.read()
        if not filestr:
            logger.error("Empty frame data")
            return jsonify({'error': 'Empty frame data'}), 400
            
        npimg = np.frombuffer(filestr, np.uint8)
        frame = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
        
        if frame is None:
            logger.error("Failed to decode frame")
            return jsonify({'error': 'Failed to decode frame'}), 400

        # Process the frame
        processed_frame = virtual_trial.process_frame(frame, real_path)
        if processed_frame is not None:
            ret, jpeg = cv2.imencode('.jpg', processed_frame)
            if ret:
                return jsonify({'image': base64.b64encode(jpeg.tobytes()).decode('utf-8')})
            else:
                logger.error("Failed to encode processed frame")
                return jsonify({'error': 'Failed to encode processed frame'}), 500
        else:
            logger.info("No face detected or no sprite applied")
            return jsonify({'error': 'No face detected or no sprite applied'}), 404
    except FileNotFoundError as e:
        logger.error(f"File not found: {str(e)}")
        return jsonify({'error': f'File not found: {str(e)}'}), 404
    except ValueError as e:
        logger.error(f"Value error: {str(e)}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Unexpected error in process_frame_upload: {str(e)}")
        return jsonify({'error': 'An unexpected error occurred during processing'}), 500

@app.route('/')
def index() -> str:
    """
    Render the main index page
    
    Returns:
        Rendered HTML template
    """
    return render_template('jewelry_brand.html')

@app.route('/original_index')
def original_index() -> str:
    """
    Render the original index page for the virtual try-on feature
    
    Returns:
        Rendered HTML template
    """
    try:
        logger.info("Loading virtual try-on page")
        return render_template('index.html')
    except Exception as e:
        logger.error(f"Error rendering virtual try-on page: {str(e)}")
        # Provide a fallback page if the original index.html is not found
        return render_template('error.html', error="Virtual try-on feature is not available")

@app.route('/jewelry')
def jewelry_brand() -> str:
    """
    Render the jewelry brand main page
    
    Returns:
        Rendered HTML template
    """
    return render_template('jewelry_brand.html')

@app.route('/jewelry_brand')
def jewelry_brand_route() -> str:
    """
    Render the jewelry brand main page (alternate route)
    
    Returns:
        Rendered HTML template
    """
    return render_template('jewelry_brand.html')

@app.route('/checkout')
def checkout() -> str:
    """
    Render the checkout page
    
    Returns:
        Rendered HTML template
    """
    try:
        logger.info("Loading checkout page")
        return render_template('jewelry_checkout.html')
    except Exception as e:
        logger.error(f"Error rendering checkout page: {str(e)}")
        return render_template('error.html', error="Checkout page is temporarily unavailable")

@app.route('/api/docs')
def api_docs() -> str:
    """
    Render API documentation page
    
    Returns:
        Rendered HTML template with API documentation
    """
    # Define the API endpoints for documentation
    endpoints = [
        {
            'name': 'GET /',
            'description': 'Main page of the application',
            'parameters': None,
            'returns': 'HTML page',
            'rate_limit': None
        },
        {
            'name': 'GET /tryon/{file_path}',
            'description': 'Page for trying on a specific item',
            'parameters': [
                {'name': 'file_path', 'type': 'string', 'description': 'Path to the item to try on'}
            ],
            'returns': 'HTML checkout page',
            'rate_limit': '30 per minute'
        },
        {
            'name': 'POST /upload_frame',
            'description': 'Process a frame with virtual try-on',
            'parameters': [
                {'name': 'frame', 'type': 'file', 'description': 'Image frame to process'},
                {'name': 'json_data', 'type': 'JSON string', 'description': 'JSON containing file_path'}
            ],
            'returns': 'JSON with processed image or error',
            'rate_limit': '60 per minute'
        }
    ]
    
    return render_template('api_docs.html', endpoints=endpoints)

@app.errorhandler(404)
def page_not_found(e) -> Tuple[str, int]:
    """
    Handle 404 errors
    
    Args:
        e: The error object
        
    Returns:
        Error template with 404 status code
    """
    logger.error(f"404 error: {str(e)}")
    return render_template('error.html', error="Page not found"), 404

@app.errorhandler(500)
def internal_server_error(e) -> Tuple[str, int]:
    """
    Handle 500 errors
    
    Args:
        e: The error object
        
    Returns:
        Error template with 500 status code
    """
    logger.error(f"500 error: {str(e)}")
    return render_template('error.html', error="Internal server error"), 500

@app.errorhandler(429)
def ratelimit_handler(e) -> Tuple[str, int]:
    """
    Handle rate limit exceeded errors
    
    Args:
        e: The error object
        
    Returns:
        Error template with 429 status code
    """
    logger.warning(f"Rate limit exceeded: {str(e)}")
    return render_template('error.html', 
                          error="Too many requests. Please try again later."), 429

@socketio.on('connect')
def handle_connect():
    """Handle new WebSocket connections"""
    logger.info(f"Client connected: {request.sid}")

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnections"""
    logger.info(f"Client disconnected: {request.sid}")

@socketio.on('stream_frame')
def handle_stream_frame(data):
    """
    Handle incoming video frames from the client
    
    Args:
        data (dict): Dictionary containing 'frame' (base64 image) and 'file_path'
    """
    # Initialize caches for performance if they don't exist
    if not hasattr(handle_stream_frame, 'path_cache'):
        handle_stream_frame.path_cache = {}
    
    # Initialize last valid path tracking for error recovery
    if not hasattr(handle_stream_frame, 'last_valid_path'):
        handle_stream_frame.last_valid_path = None
    
    # Log raw received data (truncated for readability)
    if isinstance(data, dict) and 'frame' in data:
        # Create a copy with truncated frame data for logging
        log_data = data.copy()
        log_data['frame'] = f"[base64 data of length {len(log_data.get('frame', ''))}]"
        logger.info(f"SocketIO received stream_frame event. Data: {log_data}")
    else:
        logger.warning(f"Invalid stream data received: {data}")
        emit('stream_error', {'error': 'Invalid data received from client'})
        return
        
    if not data or 'frame' not in data:
        logger.warning("Missing 'frame' in received data")
        emit('stream_error', {'error': 'Missing frame data'})
        return
        
    try:
        start_time = time.time()
        
        # Handle both full base64 data and split format gracefully
        base64_data = data['frame']
        try:
            if isinstance(base64_data, str) and ',' in base64_data:
                # Handle data URL format (e.g., "data:image/jpeg;base64,ABC123...")
                img_str = base64.b64decode(base64_data.split(',')[1])
            else:
                # Handle raw base64 data
                img_str = base64.b64decode(base64_data)
                
            npimg = np.frombuffer(img_str, np.uint8)
            frame = cv2.imdecode(npimg, cv2.IMREAD_UNCHANGED)  # Preserve alpha if present
        except Exception as e:
            logger.error(f"Failed to decode base64 image: {str(e)}")
            emit('stream_error', {'error': 'Failed to decode image data'})
            return
            
        if frame is None:
            logger.error("Decoded frame is None")
            emit('stream_error', {'error': 'Failed to decode frame'})
            return

        # Determine file path with fallbacks and caching
        file_path = data.get('file_path')
        real_path = None
        
        # Use path cache if available for better performance
        if file_path and file_path in handle_stream_frame.path_cache:
            real_path = handle_stream_frame.path_cache[file_path]
            logger.debug(f"Using cached path for {file_path}: {real_path}")
        
        # If no cached path, or no file_path provided, try processing the path
        if not real_path:
            if file_path:
                # Process new file path
                secure_file_path = secure_path(file_path)
                logger.info(f"Secured file_path: {secure_file_path}")
                
                if secure_file_path:
                    # Construct and normalize path
                    real_path = os.path.normpath(os.path.join('static', secure_file_path))
                    logger.info(f"Constructed real_path: {real_path}")
                    
                    # Validate path points to existing file
                    if os.path.isfile(real_path):
                        # Cache valid path for future use
                        handle_stream_frame.path_cache[file_path] = real_path
                        handle_stream_frame.last_valid_path = real_path
                    else:
                        logger.warning(f"File not found: {real_path}")
                        real_path = None
            
            # Fallback to last valid path if needed
            if not real_path and handle_stream_frame.last_valid_path:
                logger.info(f"Falling back to last valid path: {handle_stream_frame.last_valid_path}")
                real_path = handle_stream_frame.last_valid_path

        # Set the sprite path directly on the virtual dresser instance for better performance
        if real_path and hasattr(virtual_trial, 'virtual_dresser'):
            virtual_trial.virtual_dresser.selected_sprite_path = real_path
            logger.debug(f"Directly set virtual_dresser.selected_sprite_path = {real_path}")

        # Process the frame with the determined path
        processed_frame = virtual_trial.process_frame(frame, real_path)
        
        # Calculate FPS for monitoring
        processing_time = time.time() - start_time
        fps = 1.0 / max(processing_time, 0.001)  # Avoid division by zero
        
        if processed_frame is not None:
            # Encode the processed frame at good quality/speed balance
            encode_params = [int(cv2.IMWRITE_JPEG_QUALITY), 85]  
            ret, jpeg = cv2.imencode('.jpg', processed_frame, encode_params)
            
            if ret:
                # Emit processed frame back to client
                b64_string = base64.b64encode(jpeg.tobytes()).decode('utf-8')
                emit('processed_frame', {
                    'image': 'data:image/jpeg;base64,' + b64_string,
                    'fps': fps
                })
            else:
                logger.error("Failed to encode processed frame")
                emit('stream_error', {'error': 'Failed to encode processed image'})
        else:
            logger.warning("Frame processing returned None (possibly no face detected)")
            emit('no_face', {'message': 'No face detected in the image'})
            
    except Exception as e:
        logger.error(f"Error in handle_stream_frame: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        emit('stream_error', {'error': 'Server error processing the image'})

def run_app():
    """
    Entry point for running the application when installed as a package
    
    This function is used by the console script entry point in setup.py
    """
    logger.info("Starting Virtual Dressing Room application on port 5001")
    socketio.run(app, debug=False, port=5001, host="0.0.0.0")

if __name__ == '__main__':
    logger.info("Starting SocketIO server on port 5001")
    socketio.run(app, debug=True, port=5001)
