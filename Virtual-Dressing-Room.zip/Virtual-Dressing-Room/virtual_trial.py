import cv2, os
import dlib
from imutils import face_utils, rotate_bound
import math
import numpy as np
import logging
from typing import Dict, List, Tuple, Optional, Union, Any
import time
import threading
from functools import lru_cache
import queue

# Set up logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('virtual_dressing_room')

# Global frame processing queue
frame_queue = queue.Queue(maxsize=2)
result_queue = queue.Queue(maxsize=2)

class VirtualDressingRoom:
    """
    Main class that handles the virtual dressing room functionality.
    Manages sprites, images and processing of frames for virtual try-on.
    """
    
    def __init__(self, shape_predictor_path: str):
        """
        Initialize the Virtual Dressing Room
        
        Args:
            shape_predictor_path: Path to the dlib face landmarking model
        """
        # Frame processing settings for optimal quality-performance balance
        self.target_processing_width = 480  # Increased from 320 for better quality
        self.max_skip_frames = 2  # Reduced from 3 to process frames more consistently
        self.motion_threshold = 40.0  # Increased dramatically to reduce sensitivity to small movements
        self.target_fps = 20  # Reduced from 30 for even more stability
        self.rate_limit = 1.0/20  # Rate limit to 20 FPS max (50ms) for stability
        
        # Face detection visualization settings
        self.first_face_detected_time = 0  # Time when face was first detected
        self.show_landmarks = False  # Whether to show facial landmarks
        self.landmark_display_duration = 2.0  # Show landmarks for 2 seconds
        
        # Initialize sprite paths
        self.sprites_paths = {
            1: 'static/jewelry/',  # Necklaces
            2: 'static/jewelry/'   # Earrings
        }
        
        # Enable/disable specific sprite categories
        self.sprites = {
            1: True,  # Necklaces enabled by default
            2: True   # Earrings enabled by default
        }
        
        # Initialize images container
        self.images = {
            1: [],  # Necklaces
            2: []   # Earrings
        }
        
        # Active images index by category
        self.active_images = {
            1: 0,  # Active necklace index
            2: 0   # Active earrings index
        }
        
        # Selected sprite path
        self.selected_sprite_path = None
        
        # For image and photo filters
        self.images_filter = 0  # No filter by default
        
        # Photos container for UI display
        self.photos = {
            1: [],  # Necklace thumbnails
            2: []   # Earring thumbnails
        }
        
        # Create detector and predictor
        if not os.path.isfile(shape_predictor_path):
            logger.error(f"Shape predictor file not found: {shape_predictor_path}")
            raise FileNotFoundError(f"Shape predictor file not found: {shape_predictor_path}")
            
        self.detector = dlib.get_frontal_face_detector()
        self.predictor = dlib.shape_predictor(shape_predictor_path)
        
        # Initialize sprite cache for quicker access
        self.sprite_cache = {}
        
        # Frame processing variables
        self.last_processed_frame_time = 0
        self.prev_gray = None
        self.skip_frame_count = 0
        self.last_shape = None
        self.frame_count = 0
        self.last_face_bb = None
        
        # Whether jewelry was preloaded
        self.jewelry_preloaded = False
        
        # Store the model path for later use
        self.model_path = shape_predictor_path
        
        # Track last displayed debug info to prevent flickering
        self.last_debug_info = []
        
        # Preload jewelry sprites for better performance
        self._preload_jewelry_sprites()
        
    def _preload_jewelry_sprites(self):
        """Preload all jewelry files for faster access during processing"""
        try:
            # Preload necklaces
            jewelry_dir = self.sprites_paths[1]
            if os.path.isdir(jewelry_dir):
                logger.info(f"Preloading jewelry sprites from {jewelry_dir}")
                
                # Get all image files in the directory
                for filename in os.listdir(jewelry_dir):
                    if filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                        file_path = os.path.join(jewelry_dir, filename)
                        
                        # Determine category based on filename
                        category = None
                        if "necklace" in filename.lower():
                            category = 1
                        elif "earring" in filename.lower():
                            category = 2
                        else:
                            # Use the first part of the filename before numbers as a hint
                            name_part = ''.join([c for c in filename if not c.isdigit()]).strip('.png.jpg.jpeg')
                            if "necklace" in name_part.lower():
                                category = 1
                            elif "earring" in name_part.lower():
                                category = 2
                                
                        if category:
                            # Load the image and cache it
                            image = self.load_sprite_image(file_path)
                            if image is not None:
                                # Store in sprite cache
                                self.sprite_cache[file_path] = image
                                
                                # Add to appropriate category if not already present
                                if category == 1 and file_path not in [p[1] for p in self.images[1]]:
                                    self.images[1].append((image, file_path))
                                elif category == 2 and file_path not in [p[1] for p in self.images[2]]:
                                    self.images[2].append((image, file_path))
            
            self.jewelry_preloaded = True
            logger.info(f"Successfully preloaded {len(self.sprite_cache)} jewelry sprites")
        except Exception as e:
            logger.error(f"Error preloading jewelry sprites: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            
    def load_sprite_image(self, file_path: str) -> np.ndarray:
        """
        Load a sprite image with caching
        
        Args:
            file_path: Path to the image file
            
        Returns:
            Loaded sprite image as numpy array
        """
        try:
            # Check if image is already in cache
            if file_path in self.sprite_cache:
                return self.sprite_cache[file_path].copy()
                
            # Check if file exists
            if not os.path.isfile(file_path):
                logger.error(f"Sprite file not found: {file_path}")
                return None
                
            # Load the image with alpha channel
            img = cv2.imread(file_path, cv2.IMREAD_UNCHANGED)
            
            # Validate image
            if img is None:
                logger.error(f"Failed to load sprite: {file_path}")
                return None
                
            # Ensure the image has 4 channels (RGBA)
            if img.shape[2] != 4:
                logger.warning(f"Sprite {file_path} doesn't have alpha channel, adding it")
                # Convert to RGBA by adding alpha channel
                b, g, r = cv2.split(img)
                a = np.ones(b.shape, dtype=b.dtype) * 255
                img = cv2.merge((b, g, r, a))
                
            # Cache the image
            self.sprite_cache[file_path] = img.copy()
            
            return img
        except Exception as e:
            logger.error(f"Error loading sprite image {file_path}: {str(e)}")
            return None
            
    def process_frame(self, frame: np.ndarray, file_path: str = None) -> np.ndarray:
        """
        Process a video frame by detecting faces and applying sprites
        
        Args:
            frame: The input frame to process
            file_path: Optional path to the sprite file (for backwards compatibility)
            
        Returns:
            The processed frame with sprites applied
        """
        if frame is None:
            logger.error("Cannot process None frame")
            return None
        
        try:
            # Use a copy for drawing debug info, leave original frame clean until the end
            output_frame = frame.copy()
            debug_info = [] # Reset debug info for this frame
            face_detected = False
                
            # For backwards compatibility, set the selected_sprite_path if file_path is provided
            if file_path is not None:
                # Check if file exists
                if os.path.exists(file_path):
                    # Update the selected sprite path
                    self.selected_sprite_path = file_path
                    logger.info(f"Set selected_sprite_path to {file_path}")
                    debug_info.append(f"Sprite: {os.path.basename(file_path)}")
                else:
                    logger.error(f"Invalid file path provided: {file_path}")
                    debug_info.append(f"Error: Invalid file path {file_path}")
                    return frame
            else:
                debug_info.append(f"No file_path provided")
            
            # Display selected sprite path
            if self.selected_sprite_path:
                debug_info.append(f"Using: {os.path.basename(self.selected_sprite_path)}")
            else:
                debug_info.append("No sprite selected")
                
            # Make sure jewelry is preloaded
            if not self.jewelry_preloaded:
                self._preload_jewelry_sprites()
                debug_info.append("Preloading jewelry...")
                
            # Get current time for FPS control (though not displayed anymore)
            current_time = time.time()
            elapsed = current_time - self.last_processed_frame_time
            
            # Apply rate limiting for smoother video
            if elapsed < self.rate_limit:
                self.frame_count += 1
                debug_info.append("Rate limited")
                self._add_debug_info(output_frame, debug_info) # Draw on output frame
                return output_frame
                
            # Process at reduced resolution for better performance
            original_width = frame.shape[1]
            original_height = frame.shape[0]
            
            # Resize only if the frame is significantly larger than target width
            if original_width > self.target_processing_width * 1.2:
                scale_factor = self.target_processing_width / original_width
                resized_width = self.target_processing_width
                resized_height = int(original_height * scale_factor)
                
                # Resize with high quality interpolation
                working_frame = cv2.resize(frame, (resized_width, resized_height), 
                                           interpolation=cv2.INTER_LANCZOS4)
            else:
                # Use original frame if it's already close to target size
                working_frame = frame.copy()
                scale_factor = 1.0
                
            # Adaptive frame skipping based on motion detection
            if self.prev_gray is not None and self.skip_frame_count < self.max_skip_frames:
                # Convert current frame to grayscale for motion detection
                current_gray = cv2.cvtColor(working_frame, cv2.COLOR_BGR2GRAY)
                
                # Calculate optical flow for motion detection
                flow = cv2.calcOpticalFlowFarneback(
                    self.prev_gray, current_gray, None,
                    0.5, 3, 15, 3, 5, 1.2, 0
                )
                
                # Calculate motion magnitude
                mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
                motion = np.mean(mag)
                
                # Update previous gray frame
                self.prev_gray = current_gray
                
                # If motion is below threshold, skip this frame
                if motion < self.motion_threshold:
                    self.skip_frame_count += 1
                    
                    # If we have processed a face before, apply the last face landmarks
                    if self.last_shape is not None and self.last_face_bb is not None:
                        try:
                            # Use the last detected face information
                            x, y, w, h = self.last_face_bb
                            
                            # Adjust for any resize
                            x = int(x / scale_factor)
                            y = int(y / scale_factor)
                            w = int(w / scale_factor)
                            h = int(h / scale_factor)
                            
                            # Apply sprites using last detected shape
                            adjusted_shape = np.array([
                                [int(p[0] / scale_factor), int(p[1] / scale_factor)]
                                for p in self.last_shape
                            ])
                            
                            # Calculate face inclination from the shape
                            incl = 0
                            if len(adjusted_shape) >= 27:
                                incl = np.arctan2(adjusted_shape[27][1] - adjusted_shape[8][1],
                                                 adjusted_shape[27][0] - adjusted_shape[8][0])
                            
                            # Check if we should display landmarks
                            show_landmarks_now = False
                            if self.first_face_detected_time > 0:
                                time_since_detection = current_time - self.first_face_detected_time
                                if time_since_detection < self.landmark_display_duration:
                                    show_landmarks_now = True
                                    debug_info.append(f"Showing landmarks: {time_since_detection:.1f}s")
                            
                            # Draw facial landmarks if needed
                            if show_landmarks_now:
                                self._draw_facial_landmarks(frame, adjusted_shape)
                            
                            # Apply sprites using last shape information
                            applied = self._process_face(frame, adjusted_shape, x, y, w, h, incl)
                            if applied:
                                face_detected = True
                                debug_info.append("Using cached face")
                            else:
                                debug_info.append("Cache sprite apply failed")
                            
                            logger.info(f"Applied sprites using cached face data (skip frame {self.skip_frame_count})")
                        except Exception as e:
                            logger.error(f"Error applying cached face data: {str(e)}")
                            debug_info.append(f"Cache error: {str(e)}")
                    
                    self.frame_count += 1
                    self.last_processed_frame_time = current_time
                    self._add_debug_info(output_frame, debug_info) # Draw on output frame
                    return output_frame
                    
            # Reset skip counter
            self.skip_frame_count = 0
            
            # Detect faces in the frame
            faces = self.detector(working_frame, 0)
            debug_info.append(f"Detected faces: {len(faces)}")
            
            # Process at most one face (first detected)
            if len(faces) > 0:
                face_detected = True
                # Get face bounding box
                face = faces[0]
                x, y, w, h = face.left(), face.top(), face.width(), face.height()
                
                # Scale back bounding box coordinates for original frame
                x_orig = int(x / scale_factor)
                y_orig = int(y / scale_factor)
                w_orig = int(w / scale_factor)
                h_orig = int(h / scale_factor)
                
                # Try to get face shape using dlib
                try:
                    # Get face landmarks
                    shape = self.predictor(working_frame, face)
                    
                    # Convert shape to numpy array
                    shape_np = np.array([[p.x, p.y] for p in shape.parts()])
                    
                    # Scale shape back to original frame size
                    scaled_shape = np.array([[int(p[0] / scale_factor), int(p[1] / scale_factor)] 
                                            for p in shape_np])
                    
                    # Calculate face inclination
                    incl = 0
                    if len(shape_np) >= 27:
                        incl = np.arctan2(shape_np[27][1] - shape_np[8][1],
                                        shape_np[27][0] - shape_np[8][0])
                    
                    # Store last shape for future frame skipping
                    self.last_shape = shape_np
                    self.last_face_bb = (x, y, w, h)
                    
                    # If this is the first face detection, record the time
                    if self.first_face_detected_time == 0:
                        self.first_face_detected_time = current_time
                        debug_info.append("First face detected")
                    
                    # Check if we should display landmarks
                    show_landmarks_now = False
                    if self.first_face_detected_time > 0:
                        time_since_detection = current_time - self.first_face_detected_time
                        if time_since_detection < self.landmark_display_duration:
                            show_landmarks_now = True
                            debug_info.append(f"Showing landmarks: {time_since_detection:.1f}s")
                    
                    # Draw facial landmarks if needed
                    if show_landmarks_now:
                        self._draw_facial_landmarks(frame, scaled_shape)
                    
                    # Apply sprites ON THE ORIGINAL FRAME (passed as 'frame')
                    applied = self._process_face(frame, scaled_shape, x_orig, y_orig, w_orig, h_orig, incl)
                    if applied:
                        debug_info.append("Sprite applied successfully")
                    else:
                        debug_info.append("Failed to apply sprite")
                    
                    # Update previous grayscale frame for motion detection
                    self.prev_gray = cv2.cvtColor(working_frame, cv2.COLOR_BGR2GRAY)
                    
                    logger.info(f"Successfully processed frame with face at ({x_orig}, {y_orig}, {w_orig}, {h_orig})")
                except Exception as e:
                    logger.error(f"Error processing face: {str(e)}")
                    debug_info.append(f"Face error: {str(e)}")
                    self.last_shape = None
                    self.last_face_bb = None
            else:
                # No face detected
                self.last_shape = None
                self.last_face_bb = None
                debug_info.append("No face detected")
                logger.info("No face detected in frame")
                
                # Initialize prev_gray if needed
                if self.prev_gray is None and working_frame is not None:
                    self.prev_gray = cv2.cvtColor(working_frame, cv2.COLOR_BGR2GRAY)
            
            # Update frame count and time
            self.frame_count += 1
            self.last_processed_frame_time = current_time
            
            # Add debug information to the output frame (conditionally)
            self._add_debug_info(output_frame, debug_info)
            
            # IMPORTANT: Return the ORIGINAL frame with sprites applied, NOT the debug frame
            # The debug info is now drawn separately if needed, or overlaid on a copy if returned
            # If you want the debug info ON the returned frame, return output_frame instead
            # For now, returning the original frame to keep it clean
            # If you want the debug info overlay, change the return below: 
            # return output_frame 
            return frame # Return original frame (sprites are applied directly to it in _process_face -> apply_sprite)
        except Exception as e:
            logger.error(f"Error in process_frame: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return frame

    def _add_debug_info(self, frame: np.ndarray, debug_info: List[str]) -> None:
        """Add debug information to the frame as text overlay, only if changed."""
        # Only draw if debug info content has changed
        if frame is None or debug_info == self.last_debug_info:
             return
            
        # Draw debug text overlay in top-right corner instead of bottom-left
        (h, w) = frame.shape[:2]
        font_scale = 0.3  # Even smaller font
        thickness = 1
        
        # Make info more concise - take only key information
        compact_info = []
        for text in debug_info:
            # Keep only the most important status messages
            if any(key in text for key in ["Using:", "Detected", "applied", "landmarks"]):
                # Shorten text if possible
                if "Using: " in text:
                    text = text.replace("Using: ", "")  # Just show filename
                compact_info.append(text)
                
        # Limit to at most 2 items
        if len(compact_info) > 2:
            compact_info = compact_info[:2]
            
        # Start in top-right corner
        text_padding = 5
        y_start = 15  # Start from top
        x_position = w - 120  # Right side
        
        for i, text in enumerate(compact_info):
            y = y_start + i * 12  # Smaller line spacing
            
            # Get text size
            (text_width, text_height), baseline = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, font_scale, thickness)
            
            # Ensure text stays within frame bounds
            if x_position + text_width > w:
                x_position = w - text_width - text_padding
                
            # Draw text with semi-transparent muted color (light gray with alpha)
            # Semi-transparent gray color (160, 160, 160)
            cv2.putText(frame, text, (x_position, y), 
                        cv2.FONT_HERSHEY_SIMPLEX, font_scale, 
                        (160, 160, 160), thickness, cv2.LINE_AA)

        # Update last debug info cache
        self.last_debug_info = debug_info.copy()

    def initialize_images_and_photos(self, file_path: str) -> None:
        """
        Initialize images and photos from the given file path
        
        Args:
            file_path: Path to the image file
            
        Raises:
            ValueError: If file path is invalid
            FileNotFoundError: If file doesn't exist
            IOError: If image can't be loaded
        """
        try:
            # Validate file path
            if not file_path or not isinstance(file_path, str):
                raise ValueError("Invalid file path provided")
                
            if not os.path.exists(file_path):
                raise FileNotFoundError(f"File not found: {file_path}")
                
            # Get category using the same method as the rest of the code
            idx = self.get_category_number(file_path)
            
            # If the category is invalid (-1), log and exit
            if idx == -1:
                logger.warning(f"Not a recognized jewelry type: {file_path}")
                return
                
            if os.path.isfile(file_path):
                # Use IMREAD_UNCHANGED to ensure alpha channel is preserved for PNG images
                logger.info(f"Loading image from {file_path} for category {idx}")
                sprite_image = cv2.imread(file_path, cv2.IMREAD_UNCHANGED)
                
                if sprite_image is None:
                    logger.error(f"Failed to load image from {file_path}")
                    raise IOError(f"Failed to load image from {file_path}")
                
                # Check if the image has an alpha channel
                if len(sprite_image.shape) < 3 or sprite_image.shape[2] != 4:
                    logger.error(f"Image {file_path} does not have an alpha channel. Shape: {sprite_image.shape}")
                    # Try to convert it to RGBA if it's RGB
                    if len(sprite_image.shape) == 3 and sprite_image.shape[2] == 3:
                        logger.info(f"Converting RGB image to RGBA by adding alpha channel")
                        # Add an alpha channel filled with 255 (fully opaque)
                        alpha_channel = np.ones(sprite_image.shape[:2], dtype=sprite_image.dtype) * 255
                        sprite_image = cv2.merge((sprite_image[:, :, 0], sprite_image[:, :, 1], sprite_image[:, :, 2], alpha_channel))
                    else:
                        raise IOError(f"Image {file_path} has invalid format: {sprite_image.shape}")
                
                logger.info(f"Successfully loaded image with shape {sprite_image.shape}")
                self.images[idx].append(sprite_image)
                photo = cv2.resize(sprite_image, (150, 100))
                self.photos[idx].append(photo) if idx in self.photos else self.photos.update({idx: [photo]})
                logger.info(f"Added image to category {idx}")
                
                # Enable this sprite automatically after loading
                k = self.get_k(file_path)
                if k >= 0:
                    self.put_sprite(idx, k)
                    logger.info(f"Enabled sprite category {idx} with image {k}")
                else:
                    # If k couldn't be determined, just use 0 as default
                    self.put_sprite(idx, 0)
                    logger.info(f"Enabled sprite category {idx} with default image 0")
        except Exception as e:
            logger.error(f"Error initializing images: {str(e)}")
            raise

    def put_sprite(self, num: int, k: int) -> None:
        """
        Enable a sprite and set its active image
        
        Args:
            num: Sprite category number
            k: Index of the image in the category
        """
        self.sprites[num] = True  # Use boolean instead of integer
        self.active_images[num] = k if self.sprites[num] else None

    def draw_sprite(self, frame: np.ndarray, sprite: np.ndarray, x_offset: int, y_offset: int) -> np.ndarray:
        """
        Draw a sprite on the frame with alpha blending
        
        Args:
            frame: Frame to draw on
            sprite: Sprite to draw
            x_offset: X position
            y_offset: Y position
            
        Returns:
            Frame with sprite drawn
        """
        try:
            if sprite is None or frame is None:
                logger.error("Cannot draw None sprite or on None frame")
                return frame
                
            h, w = sprite.shape[0], sprite.shape[1]
            logger.info(f"Drawing sprite with dimensions ({w}, {h}) at position ({x_offset}, {y_offset})")
            
            # Check if sprite would be drawn entirely outside the frame
            if x_offset >= frame.shape[1] or y_offset >= frame.shape[0] or x_offset + w <= 0 or y_offset + h <= 0:
                logger.warning(f"Sprite would be drawn entirely outside the frame - frame dims: {frame.shape}, sprite pos: ({x_offset}, {y_offset})")
                return frame
            
            # Important: DO NOT create a copy of the frame - we want to modify the original
            # This is critical to make the sprites visible in the output
            
            # Calculate the valid drawing region (intersection of sprite and frame)
            x_start = max(0, x_offset)
            y_start = max(0, y_offset)
            x_end = min(frame.shape[1], x_offset + w)
            y_end = min(frame.shape[0], y_offset + h)
            
            # Calculate corresponding regions in the sprite
            sprite_x_start = x_start - x_offset if x_offset < 0 else 0
            sprite_y_start = y_start - y_offset if y_offset < 0 else 0
            sprite_x_end = w - (x_offset + w - x_end) if x_offset + w > frame.shape[1] else w
            sprite_y_end = h - (y_offset + h - y_end) if y_offset + h > frame.shape[0] else h
            
            # Get alpha channel and RGB channels separately
            if sprite.shape[2] == 4:  # With alpha channel
                # Extract sprite region
                sprite_region = sprite[sprite_y_start:sprite_y_end, sprite_x_start:sprite_x_end]
                
                # Extract alpha channel and normalize
                alpha = sprite_region[:, :, 3].astype(float) / 255.0
                
                # Reshape alpha for broadcasting
                alpha = alpha[:, :, np.newaxis]
                
                # Extract frame region
                frame_region = frame[y_start:y_end, x_start:x_end]
                
                # Apply alpha blending directly to the original frame
                # This is the alpha blending formula: result = foreground * alpha + background * (1-alpha)
                blended = sprite_region[:, :, 0:3] * alpha + frame_region * (1.0 - alpha)
                
                # Ensure output is uint8
                frame[y_start:y_end, x_start:x_end] = blended.astype(np.uint8)
                
                logger.info(f"Applied sprite with alpha blending: region ({x_start}:{x_end}, {y_start}:{y_end})")
            else:
                # No alpha channel, just copy the sprite
                frame[y_start:y_end, x_start:x_end] = sprite[sprite_y_start:sprite_y_end, sprite_x_start:sprite_x_end]
                logger.info("Applied sprite without alpha channel (direct copy)")
            
            return frame  # Return the modified original frame
        except IndexError as e:
            logger.error(f"Index error while drawing sprite: {str(e)}")
            logger.error(f"Frame shape: {frame.shape}, Sprite final dimensions: ({h}, {w}), Position: ({x_offset}, {y_offset})")
            return frame
        except Exception as e:
            logger.error(f"Error drawing sprite: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return frame  # Return original frame if there's an error

    def adjust_sprite2head(self, sprite: np.ndarray, head_width: int, head_ypos: int, ontop: bool = True, quality_factor: float = 1.0) -> Tuple[np.ndarray, int]:
        """
        Adjust sprite size and position relative to head dimensions
        
        Args:
            sprite: The sprite to adjust
            head_width: Width to scale to
            head_ypos: Y position of the head
            ontop: Whether the sprite is placed on top of the head
            quality_factor: Enhancement factor for sprite resizing (default: 1.0)
            
        Returns:
            Tuple of adjusted sprite and final y position
        """
        try:
            if sprite is None:
                raise ValueError("Invalid sprite provided")
                
            # Simple resize approach - prioritize stability over quality
            # Directly resize to the target width with basic interpolation
            h, w = sprite.shape[:2]
            scale_factor = head_width / w
            
            # Cap the scale factor for stability
            if scale_factor > 1.0:
                scale_factor = 1.0
                
            # Use simple, reliable interpolation for stability
            interpolation = cv2.INTER_LINEAR
                
            # Resize with basic interpolation
            new_height = int(h * scale_factor)
            resized_sprite = cv2.resize(sprite, (head_width, new_height), interpolation=interpolation)
            
            # Calculate position (above or below head)
            y_orig = head_ypos - new_height if ontop else head_ypos
            
            # Handle case where the sprite would go above the image
            if y_orig < 0:
                # Crop sprite to fit within the image
                resized_sprite = resized_sprite[abs(y_orig):, :, :]
                y_orig = 0
                
            return resized_sprite, y_orig
        except Exception as e:
            logger.error(f"Error adjusting sprite: {str(e)}")
            raise
    
    def apply_sprite(self, frame: np.ndarray, sprite: np.ndarray, w: int, x: int, y: int, angle: float, ontop: bool = True, quality_factor: float = 1.0) -> None:
        """
        Apply a sprite to the frame with rotation and scaling
        
        Args:
            frame: The frame to apply the sprite to
            sprite: The sprite to apply
            w: Width to scale to
            x: X position
            y: Y position
            angle: Rotation angle
            ontop: Whether to place on top
            quality_factor: Enhancement factor for sprite quality
        """
        # Only rotate if angle is significant (optimization)
        if abs(angle) > 0.05:  # About 3 degrees
            sprite = rotate_bound(sprite, angle)
        
        # Adjust sprite size and position with quality enhancement
        (sprite, y_final) = self.adjust_sprite2head(sprite, w, y, ontop, quality_factor)
        frame = self.draw_sprite(frame, sprite, x, y_final)

    def get_face_boundbox(self, points: np.ndarray, face_part: int) -> Tuple[int, int, int, int]:
        """
        Get bounding box coordinates for a specific face part
        
        Args:
            points: Facial landmark points
            face_part: Which part of the face (1-8)
            
        Returns:
            Tuple of (x, y, width, height)
        """
        mapping = {
            1: points[17:22],  # left eyebrow
            2: points[22:27],  # right eyebrow
            3: points[36:42],  # left eye
            4: points[42:48],  # right eye
            5: points[29:36],  # nose
            6: points[1:17],   # jaw
            7: points[0:6],    # left jaw
            8: points[11:17]   # right jaw
        }
        x, y, w, h = self.calculate_boundbox(mapping.get(face_part, []))
        return x, y, w, h

    @staticmethod
    def calculate_inclination(point1: np.ndarray, point2: np.ndarray) -> float:
        """
        Calculate the inclination angle between two points
        
        Args:
            point1: First point
            point2: Second point
            
        Returns:
            Angle in degrees
        """
        return 180 / math.pi * math.atan((float(point2[1] - point1[1])) / (point2[0] - point1[0]))

    @staticmethod
    def calculate_boundbox(list_coordinates: np.ndarray) -> Tuple[int, int, int, int]:
        """
        Calculate a bounding box from a list of coordinates
        
        Args:
            list_coordinates: Array of coordinates
            
        Returns:
            Tuple of (x, y, width, height)
        """
        x = min(list_coordinates[:, 0])
        y = min(list_coordinates[:, 1])
        w = max(list_coordinates[:, 0]) - min(list_coordinates[:, 0])
        h = max(list_coordinates[:, 1]) - min(list_coordinates[:, 1])
        return x, y, w, h

    @staticmethod
    def get_category_number(file_path: str) -> int:
        """
        Extract category number from file path
        
        Args:
            file_path: Path to the image file
            
        Returns:
            Category number (1 for necklaces, 2 for earrings, -1 for others)
        """
        if file_path is None:
            return -1
        
        # Replace backslashes with forward slashes to handle Windows paths
        file_path = file_path.replace('\\', '/')
        
        # Get the filename from the path
        parts = file_path.split('/')
        filename = parts[-1].lower()  # Convert to lowercase for consistent comparison
        
        # Print debug info
        logger.info(f"Determining category for filename: {filename}")
        
        if filename:
            # Check for specific jewelry types in filename
            if "necklace" in filename:
                logger.info(f"Classified {filename} as category 1 (necklace)")
                return 1  # Necklace is category 1
            elif "earrings" in filename or "earring" in filename:
                logger.info(f"Classified {filename} as category 2 (earrings)")
                return 2  # Earrings is category 2
            else:
                # Try to infer from parent directory if the filename doesn't contain category
                if len(parts) > 1:
                    parent_dir = parts[-2].lower()
                    if "necklace" in parent_dir:
                        logger.info(f"Inferred category 1 (necklace) from parent directory {parent_dir}")
                        return 1
                    elif "earrings" in parent_dir or "earring" in parent_dir:
                        logger.info(f"Inferred category 2 (earrings) from parent directory {parent_dir}")
                        return 2
            
            # If no clear category, log and return unknown
            logger.warning(f"Could not determine category for {filename}")
            return -1
        else:
            logger.error("Empty filename in path")
            return -1

    @staticmethod
    def get_k(file_path: str) -> int:
        """
        Extract item index within category from file path
        
        Args:
            file_path: Path to the image file
            
        Returns:
            Item index (0-9)
        """
        if file_path is None:
            return -1
        
        # Replace backslashes with forward slashes to handle Windows paths
        file_path = file_path.replace('\\', '/')
        
        # Get the filename from the path
        parts = file_path.split('/')
        filename = parts[-1]
        
        if filename:
            # Extract all digits from the filename
            digits = ''.join(filter(str.isdigit, filename))
            
            # Log the extracted digits for debugging
            logger.info(f"Extracted digits from {filename}: {digits}")
            
            if digits:
                try:
                    # Try to get a meaningful index from the digits
                    # For filenames like "Necklace12.png", we want to get 12 as the index
                    # not just the last digit (2)
                    val = int(digits)
                    
                    # For longer numbers, use modulo to keep within a reasonable range
                    if val > 100:
                        # For very large numbers, use modulo 100 to get a more reasonable range
                        val = val % 100
                    
                    logger.info(f"Using index {val} for file {filename}")
                    return val
                except ValueError:
                    logger.error(f"Failed to convert {digits} to integer")
                    return -1
            else:
                logger.warning(f"No digits found in filename {filename}")
                return -1
        else:
            logger.error("Empty filename in path")
            return -1

    def detect_faces(self, frame: np.ndarray) -> Tuple[List, Optional[dlib.shape_predictor], np.ndarray]:
        """Detect faces in a frame with optimization for speed"""
        # Convert to grayscale for face detection
        if frame.shape[2] == 4:  # If the image has an alpha channel
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_RGBA2RGB)
            gray = cv2.cvtColor(frame_rgb, cv2.COLOR_RGB2GRAY)
        else:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        # Performance optimization: Reduce the resolution for face detection
        # This dramatically speeds up detection with minimal accuracy loss
        scale = 0.5  # Process at half resolution
        small_gray = cv2.resize(gray, (0, 0), fx=scale, fy=scale)
            
        # Check if dlib model exists
        if os.path.exists(self.model_path):
            try:
                # Use dlib for detection (preferred method)
                predictor = dlib.shape_predictor(self.model_path)
                
                # Use smaller image for detection to improve speed
                faces = self.detector(small_gray, 0)
                
                # Scale face coordinates back to original size
                scaled_faces = []
                for face in faces:
                    scaled_faces.append(
                        dlib.rectangle(
                            int(face.left() / scale),
                            int(face.top() / scale),
                            int(face.right() / scale),
                            int(face.bottom() / scale)
                        )
                    )
                
                return scaled_faces, predictor, gray
            except Exception as e:
                return [], None, gray
        else:
            # Fallback to OpenCV's Haar cascade face detector
            try:
                # Path to the OpenCV face detection model
                opencv_face_model = os.path.join('data', 'haarcascade_frontalface_default.xml')
                
                if not os.path.exists(opencv_face_model):
                    return [], None, gray
                    
                # Load OpenCV face detector
                face_cascade = cv2.CascadeClassifier(opencv_face_model)
                
                # Detect faces on smaller image
                opencv_faces = face_cascade.detectMultiScale(
                    small_gray,
                    scaleFactor=1.1,
                    minNeighbors=5,
                    minSize=(15, 15)  # Smaller minimum size for downscaled image
                )
                
                if len(opencv_faces) == 0:
                    return [], None, gray
                
                # Scale coordinates back
                dlib_faces = []
                for (x, y, w, h) in opencv_faces:
                    # Scale back to original size
                    dlib_faces.append(dlib.rectangle(
                        int(x / scale), 
                        int(y / scale), 
                        int((x + w) / scale), 
                        int((y + h) / scale)
                    ))
                    
                return dlib_faces, None, gray
                
            except Exception as e:
                return [], None, gray
                
    def apply_category_sprite(self, frame: np.ndarray, category: int, shape: np.ndarray, 
                             x: int, y: int, w: int, incl: float) -> bool:
        """
        Apply a specific category of sprite to the frame
        
        Args:
            frame: The frame to apply to
            category: Sprite category number
            shape: Face shape landmarks
            x, y, w: Face position and width
            incl: Face inclination
            
        Returns:
            Whether a sprite was applied successfully
        """
        try:
            sprite_applied = False
            
            # Early validation
            if frame is None:
                logger.error("Cannot apply sprite to None frame")
                return False
                
            if shape is None or len(shape) < 17:
                logger.error(f"Invalid face shape data: shape length = {len(shape) if shape is not None else 0}")
                return False
                
            if category <= 0 or category > 2:
                logger.error(f"Invalid category: {category}")
                return False
                
            # Check if sprite is enabled
            if not self.sprites[category]:
                logger.warning(f"Sprite for category {category} is not enabled")
                # Auto-enable it with the first image
                if len(self.images[category]) > 0:
                    self.put_sprite(category, 0)
                    logger.info(f"Auto-enabled sprite category {category}")
                else:
                    logger.error(f"No images available to auto-enable for category {category}")
                    return False
                    
            # Check if we have images for this category
            if len(self.images[category]) == 0:
                logger.error(f"No images available for category {category}")
                # Try to load images from folder for this category
                try:
                    self._reload_jewelry_sprites(category)
                    logger.info(f"Reloaded jewelry sprites for category {category}, now have {len(self.images[category])} sprites")
                except Exception as e:
                    logger.error(f"Failed to reload jewelry sprites: {str(e)}")
                
                if len(self.images[category]) == 0:
                    return False
                
            # Check if the active image index is valid
            if self.active_images[category] >= len(self.images[category]):
                logger.error(f"Invalid active image index {self.active_images[category]} for category {category}")
                # Reset to first image
                self.active_images[category] = 0
                    
            # Necklaces (category 1) - COMPLETELY REWRITTEN FOR FIXED SIZE
            if category == 1:
                try:
                    # Get chin point for positioning
                    chin_point = shape[8]
                    
                    # Use fixed size instead of calculating from face dimensions
                    # This prevents size fluctuations that cause flickering
                    neck_width = 70  # Small fixed width
                    
                    # Position just below chin with a small offset
                    neck_y = chin_point[1] + 10  # Just slightly below chin
                    neck_x = chin_point[0]       # Centered at chin
                    
                    # Get the necklace sprite
                    if len(self.images[1]) > self.active_images[1]:
                        item = self.images[1][self.active_images[1]]
                        if isinstance(item, tuple) and len(item) >= 1:
                            necklace_sprite = item[0]
                        else:
                            necklace_sprite = item
                        
                        # Calculate offset to center the necklace horizontally
                        x_offset = neck_x - (neck_width // 2)
                        
                        # Apply necklace with minimal quality enhancement
                        # Lower quality factor to reduce processing variations
                        self.apply_sprite(frame, necklace_sprite, 
                                         neck_width, x_offset, neck_y, incl, ontop=False,
                                         quality_factor=1.0)
                        sprite_applied = True
                    else:
                        logger.error(f"Invalid image index for necklace")
                except Exception as e:
                    logger.error(f"Error applying necklace: {str(e)}")
                    import traceback
                    logger.error(traceback.format_exc())
                    
            # Earrings (category 2) - Also simplified
            elif category == 2:
                try:
                    # Use jaw points near ears for positioning
                    left_jaw_point = shape[2]
                    right_jaw_point = shape[14]
                    
                    # Use fixed small size for earrings
                    ear_width = 20  # Very small fixed width
                    
                    # Position earrings at jaw points with tiny offset
                    left_ear_x = left_jaw_point[0]
                    left_ear_y = left_jaw_point[1] + 5
                    
                    right_ear_x = right_jaw_point[0]
                    right_ear_y = right_jaw_point[1] + 5
                    
                    # Apply earrings if available
                    if len(self.images[2]) > self.active_images[2]:
                        item = self.images[2][self.active_images[2]]
                        if isinstance(item, tuple) and len(item) >= 1:
                            earring_sprite = item[0]
                        else:
                            earring_sprite = item
                        
                        # Apply left earring
                        self.apply_sprite(frame, earring_sprite, 
                                        ear_width, left_ear_x - (ear_width//2), left_ear_y, incl, ontop=False,
                                        quality_factor=1.0)
                        
                        # Right earring (flipped)
                        right_earring = cv2.flip(earring_sprite, 1)
                        self.apply_sprite(frame, right_earring, 
                                        ear_width, right_ear_x - (ear_width//2), right_ear_y, incl, ontop=False,
                                        quality_factor=1.0)
                                        
                        sprite_applied = True
                    else:
                        logger.error(f"Invalid image index for earrings")
                except Exception as e:
                    logger.error(f"Error applying earrings: {str(e)}")
                    import traceback
                    logger.error(traceback.format_exc())
                    
            return sprite_applied
        except Exception as e:
            logger.error(f"Error in apply_category_sprite: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return False
        
    def _reload_jewelry_sprites(self, category: int) -> None:
        """Force reload jewelry sprites for a specific category"""
        logger.info(f"Reloading jewelry sprites for category {category}")
        
        jewelry_dir = self.sprites_paths[category]
        if not os.path.isdir(jewelry_dir):
            logger.error(f"Jewelry directory not found: {jewelry_dir}")
            return
            
        # Clear existing sprites for this category
        self.images[category] = []
        
        # Get all images for the requested category
        for filename in os.listdir(jewelry_dir):
            file_path = os.path.join(jewelry_dir, filename)
            if not os.path.isfile(file_path):
                continue
            
            # Use lowercase checks for consistency
            filename_lower = filename.lower()
                
            # Better earring detection - check for multiple variations of earring naming
            if category == 1 and "necklace" in filename_lower:
                # Load necklace
                image = self.load_sprite_image(file_path)
                if image is not None:
                    self.images[category].append((image, file_path))
                    logger.info(f"Loaded necklace: {file_path}")
            elif category == 2 and any(term in filename_lower for term in ["earring", "earrings", "ear"]):
                # Load earring with more flexible naming detection
                image = self.load_sprite_image(file_path)
                if image is not None:
                    self.images[category].append((image, file_path))
                    logger.info(f"Loaded earring: {file_path}")
        
        # Sort images based on filename to ensure consistent ordering
        if category in self.images and len(self.images[category]) > 0:
            # If we have tuples with filenames, sort by filename
            if isinstance(self.images[category][0], tuple) and len(self.images[category][0]) >= 2:
                self.images[category].sort(key=lambda x: x[1])
                    
        logger.info(f"Reloaded {len(self.images[category])} sprites for category {category}")
        
        # If this is the active category and we have images, make sure active_images index is valid
        if self.sprites[category] and len(self.images[category]) > 0:
            if self.active_images[category] >= len(self.images[category]):
                self.active_images[category] = 0
                logger.info(f"Reset active image index for category {category} to 0")

    def _process_face(self, frame: np.ndarray, shape: np.ndarray, 
                      x: int, y: int, w: int, h: int, 
                      incl: float = 0) -> bool:
        """
        Process a detected face and apply appropriate sprites
        
        Args:
            frame: The input frame to process
            shape: Facial landmarks array
            x, y, w, h: Face bounding box coordinates
            incl: Face inclination in radians
            
        Returns:
            Whether any sprites were applied successfully
        """
        try:
            if self.selected_sprite_path is None:
                logger.warning("No sprite path selected, cannot apply sprites")
                return False
                
            # Make sure jewelry sprites are preloaded
            if not self.jewelry_preloaded:
                self._preload_jewelry_sprites()
                
            # Get category number from selected sprite path
            category = self.get_category_number(self.selected_sprite_path)
            
            # Print debug information about the selected file path
            logger.info(f"Processing sprite: {self.selected_sprite_path}, Category: {category}")
            
            # Validate category number
            if category <= 0:
                logger.warning(f"Invalid category from path: {self.selected_sprite_path}")
                # Try to infer category from filename
                if "necklace" in self.selected_sprite_path.lower():
                    category = 1
                elif "earring" in self.selected_sprite_path.lower():
                    category = 2
                else:
                    return False
                logger.info(f"Inferred category {category} from filename")
                
            # Initialize images for this category if not already done
            if len(self.images[category]) == 0:
                # Reload sprites for this category from directory
                self._reload_jewelry_sprites(category)
                logger.info(f"Reloaded sprites for category {category}")
                
                # If still no images, try loading the selected file directly
                if len(self.images[category]) == 0:
                    if os.path.exists(self.selected_sprite_path):
                        image = self.load_sprite_image(self.selected_sprite_path)
                        if image is not None:
                            # Add to the category images
                            self.images[category] = [(image, self.selected_sprite_path)]
                            self.active_images[category] = 0
                            logger.info(f"Loaded selected sprite directly: {self.selected_sprite_path}")
                        else:
                            logger.error(f"Failed to load selected sprite: {self.selected_sprite_path}")
                            return False
                    else:
                        logger.error(f"Selected sprite file not found: {self.selected_sprite_path}")
                        return False
            
            # Find the correct sprite in the image list
            file_name = os.path.basename(self.selected_sprite_path)
            found = False
            for i, item in enumerate(self.images[category]):
                if isinstance(item, tuple) and len(item) >= 2:
                    if os.path.basename(item[1]) == file_name:
                        self.active_images[category] = i
                        found = True
                        logger.info(f"Found sprite {file_name} at index {i}")
                        break
            
            if not found:
                # If it's not in the list, reload sprites for this category
                old_length = len(self.images[category])
                self._reload_jewelry_sprites(category)
                
                if len(self.images[category]) > old_length:
                    # Check if the file is now in the list
                    for i, item in enumerate(self.images[category]):
                        if isinstance(item, tuple) and len(item) >= 2:
                            if os.path.basename(item[1]) == file_name:
                                self.active_images[category] = i
                                found = True
                                logger.info(f"Found sprite after reload at index {i}")
                                break
                    
                    if not found:
                        # If still not found, force-load it
                        logger.info(f"Selected sprite not found after reload, force-loading: {self.selected_sprite_path}")
                        if os.path.exists(self.selected_sprite_path):
                            image = self.load_sprite_image(self.selected_sprite_path)
                            if image is not None:
                                # Add to the category images
                                self.images[category].append((image, self.selected_sprite_path))
                                self.active_images[category] = len(self.images[category]) - 1
                                found = True
                                logger.info(f"Force-loaded sprite as index {self.active_images[category]}")
            
            # Always enable sprite for this category
            self.sprites[category] = True
            
            # Debug log the state
            logger.info(f"Category {category} active: {self.sprites[category]}, Active index: {self.active_images[category]}, Images: {len(self.images[category])}")
            
            # Apply the sprite based on category
            sprite_applied = self.apply_category_sprite(
                frame, category, shape, x, y, w, incl
            )
            
            if not sprite_applied:
                logger.warning(f"Failed to apply sprite for category {category}")
                
            return sprite_applied
        except Exception as e:
            logger.error(f"Error in _process_face: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return False

    def _draw_facial_landmarks(self, frame: np.ndarray, shape: np.ndarray) -> None:
        """
        Draw facial landmarks on frame
        
        Args:
            frame: Frame to draw on
            shape: Facial landmark points array
        """
        if frame is None or shape is None or len(shape) == 0:
            return
        
        # Draw all facial landmarks as orange dots
        for (x, y) in shape:
            cv2.circle(frame, (x, y), 3, (0, 165, 255), -1)  # Orange color, filled circle
            
        # Draw jaw line
        for i in range(0, 16):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
            
        # Draw right eyebrow
        for i in range(17, 21):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
            
        # Draw left eyebrow
        for i in range(22, 26):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
            
        # Draw nose line
        for i in range(27, 30):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
            
        # Draw nose bottom
        for i in range(31, 35):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
        
        # Draw right eye
        for i in range(36, 41):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
        # Close right eye
        cv2.line(frame, (shape[41][0], shape[41][1]), (shape[36][0], shape[36][1]), (0, 165, 255), 1)
        
        # Draw left eye
        for i in range(42, 47):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
        # Close left eye
        cv2.line(frame, (shape[47][0], shape[47][1]), (shape[42][0], shape[42][1]), (0, 165, 255), 1)
        
        # Draw mouth outer
        for i in range(48, 59):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
        # Close mouth outer
        cv2.line(frame, (shape[59][0], shape[59][1]), (shape[48][0], shape[48][1]), (0, 165, 255), 1)
        
        # Draw mouth inner
        for i in range(60, 67):
            pt1 = (shape[i][0], shape[i][1])
            pt2 = (shape[i+1][0], shape[i+1][1])
            cv2.line(frame, pt1, pt2, (0, 165, 255), 1)
        # Close mouth inner
        cv2.line(frame, (shape[67][0], shape[67][1]), (shape[60][0], shape[60][1]), (0, 165, 255), 1)

    def calculate_face_inclination(self, shape: np.ndarray) -> float:
        """
        Calculate face inclination angle in radians
        
        Args:
            shape: Facial landmark points array
            
        Returns:
            Inclination angle in radians
        """
        try:
            if shape is None or len(shape) < 28:
                logger.warning("Not enough facial landmarks to calculate inclination")
                return 0.0
            
            # Use nose bridge and chin for more stable inclination calculation
            nose_bridge = shape[27]  # Top of nose bridge
            chin = shape[8]          # Bottom of chin
            
            # Calculate angle in radians
            dx = nose_bridge[0] - chin[0]
            dy = nose_bridge[1] - chin[1]
            
            # Avoid division by zero
            if abs(dx) < 1e-6:
                if dy > 0:
                    return np.pi/2  # 90 degrees
                else:
                    return -np.pi/2  # -90 degrees
                
            # Calculate and return angle
            angle = np.arctan2(dy, dx)
            
            # Limit the angle range for stability
            angle = max(min(angle, np.pi/4), -np.pi/4)
            
            logger.debug(f"Face inclination: {angle:.2f} radians ({angle * 180 / np.pi:.1f} degrees)")
            return angle
        except Exception as e:
            logger.error(f"Error calculating face inclination: {str(e)}")
            return 0.0

    # Add this as a new method in the VirtualDressingRoom class
    def stabilize_face_position(self, current_face_bb, current_shape, smoothing_factor=0.9):
        """
        Stabilize face position to reduce flickering of applied sprites
        
        Args:
            current_face_bb: Current face bounding box (x,y,w,h)
            current_shape: Current face shape landmarks
            smoothing_factor: How much to favor the previous position (0-1)
            
        Returns:
            Stabilized face bounding box and shape
        """
        if self.last_face_bb is None or self.last_shape is None:
            return current_face_bb, current_shape
            
        # Unpack bounding boxes
        x, y, w, h = current_face_bb
        last_x, last_y, last_w, last_h = self.last_face_bb
        
        # Apply temporal smoothing to face bounding box
        stable_x = int(last_x * smoothing_factor + x * (1 - smoothing_factor))
        stable_y = int(last_y * smoothing_factor + y * (1 - smoothing_factor))
        stable_w = int(last_w * smoothing_factor + w * (1 - smoothing_factor))
        stable_h = int(last_h * smoothing_factor + h * (1 - smoothing_factor))
        
        # Apply temporal smoothing to shape landmarks
        stable_shape = np.zeros_like(current_shape)
        for i in range(len(current_shape)):
            if i < len(self.last_shape):
                stable_shape[i][0] = int(self.last_shape[i][0] * smoothing_factor + current_shape[i][0] * (1 - smoothing_factor))
                stable_shape[i][1] = int(self.last_shape[i][1] * smoothing_factor + current_shape[i][1] * (1 - smoothing_factor))
            else:
                stable_shape[i] = current_shape[i]
                
        return (stable_x, stable_y, stable_w, stable_h), stable_shape

# Create a singleton instance
virtual_dresser = VirtualDressingRoom(shape_predictor_path="data/shape_predictor_68_face_landmarks.dat")

# For backwards compatibility, expose the public method
def process_frame(frame: np.ndarray, file_path: str = None) -> np.ndarray:
    """
    Process a video frame by detecting faces and applying sprites
    
    Args:
        frame: The input frame to process
        file_path: Optional path to the sprite file (for backwards compatibility)
        
    Returns:
        The processed frame with sprites applied
    """
    if frame is None:
        logger.error("Cannot process None frame")
        return None
        
    try:
        # Use a copy for drawing debug info, leave original frame clean until the end
        output_frame = frame.copy()
        debug_info = [] # Reset debug info for this frame
        face_detected = False
            
        # For backwards compatibility, set the selected_sprite_path if file_path is provided
        if file_path is not None:
            # Check if file exists
            if os.path.exists(file_path):
                # Update the selected sprite path
                virtual_dresser.selected_sprite_path = file_path
                logger.info(f"Set selected_sprite_path to {file_path}")
                debug_info.append(f"Sprite: {os.path.basename(file_path)}")
            else:
                logger.error(f"Invalid file path provided: {file_path}")
                debug_info.append(f"Error: Invalid file path {file_path}")
                return frame
        else:
            debug_info.append(f"No file_path provided")
        
        # Display selected sprite path
        if virtual_dresser.selected_sprite_path:
            debug_info.append(f"Using: {os.path.basename(virtual_dresser.selected_sprite_path)}")
        else:
            debug_info.append("No sprite selected")
            
        # Make sure jewelry is preloaded
        if not virtual_dresser.jewelry_preloaded:
            virtual_dresser._preload_jewelry_sprites()
            debug_info.append("Preloading jewelry...")
            
        # Get current time for FPS control (though not displayed anymore)
        current_time = time.time()
        elapsed = current_time - virtual_dresser.last_processed_frame_time
        
        # Apply rate limiting for smoother video
        if elapsed < virtual_dresser.rate_limit:
            virtual_dresser.frame_count += 1
            debug_info.append("Rate limited")
            virtual_dresser._add_debug_info(output_frame, debug_info) # Draw on output frame
            return output_frame
        
        # Process at reduced resolution for better performance
        original_width = frame.shape[1]
        original_height = frame.shape[0]
        
        # Resize only if the frame is significantly larger than target width
        if original_width > virtual_dresser.target_processing_width * 1.2:
            scale_factor = virtual_dresser.target_processing_width / original_width
            resized_width = virtual_dresser.target_processing_width
            resized_height = int(original_height * scale_factor)
            
            # Resize with high quality interpolation
            working_frame = cv2.resize(frame, (resized_width, resized_height), 
                                      interpolation=cv2.INTER_LANCZOS4)
        else:
            # Use original frame if it's already close to target size
            working_frame = frame.copy()
            scale_factor = 1.0
        
        # Adaptive frame skipping based on motion detection
        if virtual_dresser.prev_gray is not None and virtual_dresser.skip_frame_count < virtual_dresser.max_skip_frames:
            # Convert current frame to grayscale for motion detection
            current_gray = cv2.cvtColor(working_frame, cv2.COLOR_BGR2GRAY)
            
            # Calculate optical flow for motion detection
            flow = cv2.calcOpticalFlowFarneback(
                virtual_dresser.prev_gray, current_gray, None,
                0.5, 3, 15, 3, 5, 1.2, 0
            )
            
            # Calculate motion magnitude
            mag, _ = cv2.cartToPolar(flow[..., 0], flow[..., 1])
            motion = np.mean(mag)
            
            # Update previous gray frame
            virtual_dresser.prev_gray = current_gray
            
            # If motion is below threshold, skip this frame
            if motion < virtual_dresser.motion_threshold:
                virtual_dresser.skip_frame_count += 1
                
                # If we have processed a face before, apply the last face landmarks
                if virtual_dresser.last_shape is not None and virtual_dresser.last_face_bb is not None:
                    try:
                        # Use the last detected face information
                        x, y, w, h = virtual_dresser.last_face_bb
                        
                        # Adjust for any resize
                        x = int(x / scale_factor)
                        y = int(y / scale_factor)
                        w = int(w / scale_factor)
                        h = int(h / scale_factor)
                        
                        # Apply sprites using last detected shape
                        adjusted_shape = np.array([
                            [int(p[0] / scale_factor), int(p[1] / scale_factor)]
                            for p in virtual_dresser.last_shape
                        ])
                        
                        # Calculate face inclination from the shape
                        incl = 0
                        if len(adjusted_shape) >= 27:
                            incl = np.arctan2(adjusted_shape[27][1] - adjusted_shape[8][1],
                                             adjusted_shape[27][0] - adjusted_shape[8][0])
                        
                        # Check if we should display landmarks
                        show_landmarks_now = False
                        if virtual_dresser.first_face_detected_time > 0:
                            time_since_detection = current_time - virtual_dresser.first_face_detected_time
                            if time_since_detection < virtual_dresser.landmark_display_duration:
                                show_landmarks_now = True
                                debug_info.append(f"Showing landmarks: {time_since_detection:.1f}s")
                        
                        # Draw facial landmarks if needed
                        if show_landmarks_now:
                            virtual_dresser._draw_facial_landmarks(frame, adjusted_shape)
                        
                        # Apply sprites using last shape information - use directly, no need for further stabilization
                        # as we're already using cached/stable data
                        applied = virtual_dresser._process_face(frame, adjusted_shape, x, y, w, h, incl)
                        if applied:
                            face_detected = True
                            debug_info.append("Using cached face")
                        else:
                            debug_info.append("Cache sprite apply failed")
                        
                        logger.info(f"Applied sprites using cached face data (skip frame {virtual_dresser.skip_frame_count})")
                    except Exception as e:
                        logger.error(f"Error applying cached face data: {str(e)}")
                        debug_info.append(f"Cache error: {str(e)}")
                    
                virtual_dresser.frame_count += 1
                virtual_dresser.last_processed_frame_time = current_time
                virtual_dresser._add_debug_info(output_frame, debug_info) # Draw on output frame
                return output_frame
            
        # Reset skip counter
        virtual_dresser.skip_frame_count = 0
        
        # Detect faces in the frame
        faces = virtual_dresser.detector(working_frame, 0)
        debug_info.append(f"Detected faces: {len(faces)}")
        
        # Process at most one face (first detected)
        if len(faces) > 0:
            face_detected = True
            # Get face bounding box
            face = faces[0]
            x, y, w, h = face.left(), face.top(), face.width(), face.height()
            
            # Scale back bounding box coordinates for original frame
            x_orig = int(x / scale_factor)
            y_orig = int(y / scale_factor)
            w_orig = int(w / scale_factor)
            h_orig = int(h / scale_factor)
            
            # Try to get face shape using dlib
            try:
                # Get face landmarks
                shape = virtual_dresser.predictor(working_frame, face)
                
                # Convert shape to numpy array
                shape_np = np.array([[p.x, p.y] for p in shape.parts()])
                
                # Scale shape back to original frame size
                scaled_shape = np.array([[int(p[0] / scale_factor), int(p[1] / scale_factor)] 
                                        for p in shape_np])
                
                # Calculate face inclination
                incl = 0
                if len(shape_np) >= 27:
                    incl = np.arctan2(shape_np[27][1] - shape_np[8][1],
                                    shape_np[27][0] - shape_np[8][0])
                
                # APPLY STABILIZATION to face position and shape to reduce flickering
                current_face_bb = (x, y, w, h)
                stable_face_bb, stable_shape_np = virtual_dresser.stabilize_face_position(
                    current_face_bb, shape_np, smoothing_factor=0.9  # Higher smoothing for more stability
                )
                
                # Scale stabilized shape to original frame size
                stable_scaled_shape = np.array([[int(p[0] / scale_factor), int(p[1] / scale_factor)] 
                                        for p in stable_shape_np])
                
                # Store the original, unstabilized coordinates for next frame
                virtual_dresser.last_shape = shape_np
                virtual_dresser.last_face_bb = current_face_bb
                
                # If this is the first face detection, record the time
                if virtual_dresser.first_face_detected_time == 0:
                    virtual_dresser.first_face_detected_time = current_time
                    debug_info.append("First face detected")
                
                # Check if we should display landmarks
                show_landmarks_now = False
                if virtual_dresser.first_face_detected_time > 0:
                    time_since_detection = current_time - virtual_dresser.first_face_detected_time
                    if time_since_detection < virtual_dresser.landmark_display_duration:
                        show_landmarks_now = True
                        debug_info.append(f"Showing landmarks: {time_since_detection:.1f}s")
                
                # Draw facial landmarks if needed
                if show_landmarks_now:
                    virtual_dresser._draw_facial_landmarks(frame, stable_scaled_shape)
                
                # Unpack stabilized bounding box for processing
                x_stable, y_stable, w_stable, h_stable = stable_face_bb
                
                # Scale back stabilized bounding box to original frame coordinates
                x_stable_orig = int(x_stable / scale_factor)
                y_stable_orig = int(y_stable / scale_factor)
                w_stable_orig = int(w_stable / scale_factor)
                h_stable_orig = int(h_stable / scale_factor)
                
                # Apply sprites using STABILIZED face data to reduce flickering
                applied = virtual_dresser._process_face(frame, stable_scaled_shape, 
                                                      x_stable_orig, y_stable_orig, 
                                                      w_stable_orig, h_stable_orig, incl)
                if applied:
                    debug_info.append("Sprite applied successfully")
                else:
                    debug_info.append("Failed to apply sprite")
                
                # Update previous grayscale frame for motion detection
                virtual_dresser.prev_gray = cv2.cvtColor(working_frame, cv2.COLOR_BGR2GRAY)
                
                logger.info(f"Successfully processed frame with face at ({x_stable_orig}, {y_stable_orig}, {w_stable_orig}, {h_stable_orig})")
            except Exception as e:
                logger.error(f"Error processing face: {str(e)}")
                debug_info.append(f"Face error: {str(e)}")
                virtual_dresser.last_shape = None
                virtual_dresser.last_face_bb = None
        else:
            # No face detected
            virtual_dresser.last_shape = None
            virtual_dresser.last_face_bb = None
            debug_info.append("No face detected")
            logger.info("No face detected in frame")

            # Initialize prev_gray if needed
            if virtual_dresser.prev_gray is None and working_frame is not None:
                virtual_dresser.prev_gray = cv2.cvtColor(working_frame, cv2.COLOR_BGR2GRAY)
        
        # Update frame count and time
        virtual_dresser.frame_count += 1
        virtual_dresser.last_processed_frame_time = current_time
        
        # Add debug information to the output frame (conditionally)
        virtual_dresser._add_debug_info(output_frame, debug_info)
        
        # IMPORTANT: Return the ORIGINAL frame with sprites applied, NOT the debug frame
        # The debug info is now drawn separately if needed, or overlaid on a copy if returned
        # If you want the debug info ON the returned frame, return output_frame instead
        # For now, returning the original frame to keep it clean
        # If you want the debug info overlay, change the return below: 
        # return output_frame 
        return frame # Return original frame (sprites are applied directly to it in _process_face -> apply_sprite)
    except Exception as e:
        logger.error(f"Error in process_frame: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return frame
