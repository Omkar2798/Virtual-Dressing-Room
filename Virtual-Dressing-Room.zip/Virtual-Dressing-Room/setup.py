from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if not line.startswith("#")]

setup(
    name="virtual-dressing-room",
    version="1.0.0",
    author="Virtual Dressing Room Team",
    author_email="your_email@example.com",
    description="A web-based virtual dressing room application using augmented reality",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/virtual-dressing-room",
    packages=find_packages(),
    include_package_data=True,
    install_requires=requirements,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Multimedia :: Graphics",
        "Topic :: Multimedia :: Video",
        "Topic :: Scientific/Engineering :: Image Recognition",
    ],
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "virtual-dressing-room=flask_app:run_app",
        ],
    },
) 