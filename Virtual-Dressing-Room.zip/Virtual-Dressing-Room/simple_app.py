from flask import Flask, render_template, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
    """
    Render the main jewelry brand page
    """
    return render_template('jewelry_brand.html')

@app.route('/original')
def original_index():
    """
    Return the original virtual dressing room index page
    """
    # Simple placeholder HTML for the virtual dressing room
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Virtual Dressing Room</title>
        <style>
            body {
                font-family: Arial, sans-serif;
                max-width: 800px;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
            }
            h1 {
                color: #b08d57;
            }
            .content {
                background-color: #f9f9f9;
                padding: 30px;
                border-radius: 10px;
                margin-top: 20px;
            }
            button {
                background-color: #b08d57;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 5px;
                cursor: pointer;
                margin-top: 20px;
            }
            button:hover {
                background-color: #a17a44;
            }
        </style>
    </head>
    <body>
        <h1>Virtual Dressing Room</h1>
        <div class="content">
            <p>This is a placeholder for the original virtual dressing room application.</p>
            <p>The functionality to try on virtual jewelry will be integrated here.</p>
            <button>Try On Jewelry</button>
        </div>
    </body>
    </html>
    """

@app.route('/checkout')
def checkout():
    """
    Render the checkout page
    """
    return render_template('jewelry_checkout.html')

if __name__ == '__main__':
    app.run(debug=True, port=5000) 