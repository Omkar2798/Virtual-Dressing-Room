#!/bin/bash

# Virtual Dressing Room Installation Script
# This script automates the installation process for Linux and macOS

echo "==== Virtual Dressing Room Installation ===="
echo "This script will install all required dependencies and set up the application."

# Check if Python 3.7+ is installed
python_version=$(python3 --version 2>&1 | awk '{print $2}')
if [[ -z "$python_version" ]]; then
    echo "Error: Python 3 not found. Please install Python 3.7 or higher."
    exit 1
fi

major=$(echo $python_version | cut -d. -f1)
minor=$(echo $python_version | cut -d. -f2)
if [[ $major -lt 3 ]] || [[ $major -eq 3 && $minor -lt 7 ]]; then
    echo "Error: Python 3.7+ is required. Found Python $python_version"
    exit 1
fi

echo "Found Python $python_version"

# Create virtual environment
echo "Creating Python virtual environment..."
python3 -m venv venv
source venv/bin/activate

# Install pip dependencies
echo "Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# Create data directory for face recognition model
echo "Creating data directory..."
mkdir -p data

# Check if shape predictor file exists
if [[ ! -f "data/shape_predictor_68_face_landmarks.dat" ]]; then
    echo "Downloading face landmark predictor model..."
    if command -v wget > /dev/null; then
        wget http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2 -O data/shape_predictor_68_face_landmarks.dat.bz2
        bunzip2 data/shape_predictor_68_face_landmarks.dat.bz2
    elif command -v curl > /dev/null; then
        curl -L http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2 -o data/shape_predictor_68_face_landmarks.dat.bz2
        bunzip2 data/shape_predictor_68_face_landmarks.dat.bz2
    else
        echo "Error: Neither wget nor curl is installed. Please download the shape predictor manually:"
        echo "1. Download from: http://dlib.net/files/shape_predictor_68_face_landmarks.dat.bz2"
        echo "2. Extract and place the .dat file in the data directory"
    fi
fi

# Create uploads directory
echo "Creating uploads directory..."
mkdir -p uploads

# Install the package in development mode
echo "Installing Virtual Dressing Room package..."
pip install -e .

echo "==== Installation Complete ===="
echo "To run the application, activate the virtual environment and run:"
echo "  python flask_app.py"
echo ""
echo "Or use the installed console script:"
echo "  virtual-dressing-room"
echo ""
echo "Then open your browser and navigate to:"
echo "  http://localhost:5001/" 