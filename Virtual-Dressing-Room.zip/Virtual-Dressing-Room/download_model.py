import os
import urllib.request
import bz2

def download_model():
    """Download and extract the face landmarks model"""
    
    # Create data directory if it doesn't exist
    os.makedirs('data', exist_ok=True)
    
    # Target file path
    model_path = os.path.join('data', 'shape_predictor_68_face_landmarks.dat')
    compressed_path = model_path + '.bz2'
    
    # Check if model already exists
    if os.path.exists(model_path):
        print(f"Model already exists at {model_path}")
        return
    
    # URLs to try
    urls = [
        'https://github.com/davisking/dlib-models/raw/master/shape_predictor_68_face_landmarks.dat.bz2',
        'https://raw.githubusercontent.com/davisking/dlib-models/master/shape_predictor_68_face_landmarks.dat.bz2'
    ]
    
    # Try to download from each URL
    for url in urls:
        try:
            print(f"Downloading model from {url}...")
            urllib.request.urlretrieve(url, compressed_path)
            print("Download complete!")
            break
        except Exception as e:
            print(f"Failed to download from {url}: {e}")
    
    # Check if download succeeded
    if not os.path.exists(compressed_path):
        print("Failed to download the model. Please download it manually.")
        return
    
    # Extract the bz2 file
    print(f"Extracting {compressed_path}...")
    with open(model_path, 'wb') as f_out, bz2.BZ2File(compressed_path, 'rb') as f_in:
        f_out.write(f_in.read())
    print(f"Extraction complete! Model saved to {model_path}")
    
    # Optionally remove the compressed file
    os.remove(compressed_path)
    print(f"Removed compressed file {compressed_path}")

if __name__ == "__main__":
    download_model() 