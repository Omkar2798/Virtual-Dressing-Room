document.addEventListener('DOMContentLoaded', function() {
    // Tab switching functionality
    const tabButtons = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    
    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            console.log('Tab clicked:', button.getAttribute('data-tab'));
            // Remove active class from all buttons and tab contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            // Add active class to clicked button and corresponding tab content
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            const tabContent = document.getElementById(tabId);
            
            if (tabContent) {
                tabContent.classList.add('active');
                console.log('Activated tab:', tabId);
                
                // If it's the checkout tab, make sure the iframe loads
                if (tabId === 'checkout') {
                    const iframe = tabContent.querySelector('iframe');
                    if (iframe) {
                        // Reload iframe to ensure content is fresh
                        iframe.src = iframe.src;
                        console.log('Reloaded checkout iframe');
                    }
                }
            } else {
                console.error('Tab content not found for:', tabId);
            }
        });
    });

    // Cart functionality
    let cartCount = 0;
    let cartItems = [];
    const cartCountElement = document.querySelector('.cart-count');
    const cartButton = document.getElementById('cartButton');
    const cartModal = document.getElementById('cartModal');
    const closeBtn = document.querySelector('.close-btn');
    const cartItemsContainer = document.getElementById('cartItems');
    const cartTotalElement = document.getElementById('cartTotal');
    const proceedToCheckoutBtn = document.getElementById('proceedToCheckout');
    
    // Update cart count display
    function updateCartCount() {
        cartCountElement.textContent = cartCount;
        // Store cart count in localStorage for persistence
        localStorage.setItem('cartCount', cartCount);
    }
    
    // Update cart display
    function updateCartDisplay() {
        if (cartItems.length === 0) {
            cartItemsContainer.innerHTML = '<p class="empty-cart-message">Your cart is empty.</p>';
            cartTotalElement.textContent = '$0.00';
            return;
        }
        
        let total = 0;
        let cartHTML = '';
        
        cartItems.forEach((item, index) => {
            total += item.price;
            cartHTML += `
                <div class="cart-item-row">
                    <img src="${item.image}" alt="${item.name}" class="cart-item-image">
                    <div class="cart-item-details">
                        <div class="cart-item-title">${item.name}</div>
                        <div class="cart-item-price">$${item.price.toFixed(2)}</div>
                    </div>
                    <div class="cart-item-remove" data-index="${index}">
                        <i class="fas fa-times"></i>
                    </div>
                </div>
            `;
        });
        
        cartItemsContainer.innerHTML = cartHTML;
        cartTotalElement.textContent = `$${total.toFixed(2)}`;
        
        // Add event listeners to remove buttons
        document.querySelectorAll('.cart-item-remove').forEach(btn => {
            btn.addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                removeFromCart(index);
            });
        });
    }
    
    // Add item to cart
    function addToCart(item) {
        cartItems.push(item);
        cartCount++;
        updateCartCount();
        updateCartDisplay();
        // Store cart items in localStorage
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }
    
    // Remove item from cart
    function removeFromCart(index) {
        cartItems.splice(index, 1);
        cartCount--;
        updateCartCount();
        updateCartDisplay();
        // Update localStorage
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }
    
    // Load cart data from localStorage if available
    if(localStorage.getItem('cartCount')) {
        cartCount = parseInt(localStorage.getItem('cartCount'));
        updateCartCount();
    }
    
    if(localStorage.getItem('cartItems')) {
        cartItems = JSON.parse(localStorage.getItem('cartItems'));
        updateCartDisplay();
    }
    
    // Cart button opens cart modal
    if (cartButton) {
        cartButton.addEventListener('click', () => {
            cartModal.style.display = 'block';
            updateCartDisplay();
        });
    }
    
    // Close modal when clicking X
    if (closeBtn) {
        closeBtn.addEventListener('click', () => {
            cartModal.style.display = 'none';
        });
    }
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === cartModal) {
            cartModal.style.display = 'none';
        }
    });
    
    // Proceed to checkout button
    if (proceedToCheckoutBtn) {
        proceedToCheckoutBtn.addEventListener('click', () => {
            console.log('Proceed to checkout clicked');
            if (cartItems.length > 0) {
                // Close the modal
                cartModal.style.display = 'none';
                // Switch to checkout tab
                tabButtons.forEach(btn => btn.classList.remove('active'));
                tabContents.forEach(content => content.classList.remove('active'));
                
                const checkoutTab = document.querySelector('[data-tab="checkout"]');
                if (checkoutTab) {
                    checkoutTab.classList.add('active');
                    console.log('Activated checkout tab button');
                    
                    const checkoutContent = document.getElementById('checkout');
                    if (checkoutContent) {
                        checkoutContent.classList.add('active');
                        console.log('Activated checkout tab content');
                        
                        // Reload iframe to ensure content is fresh
                        const iframe = checkoutContent.querySelector('iframe');
                        if (iframe) {
                            iframe.src = iframe.src;
                            console.log('Reloaded checkout iframe');
                        }
                    } else {
                        console.error('Checkout content not found');
                    }
                } else {
                    console.error('Checkout tab button not found');
                }
            }
        });
    }

    // Jewelry Suggestion Form functionality
    const jewelryForm = document.getElementById('jewelrySuggestionForm');
    const faceImageInput = document.getElementById('faceImage');
    const imagePreview = document.getElementById('imagePreview');
    const resultContainer = document.getElementById('resultContainer');
    const recommendedProducts = document.getElementById('recommendedProducts');
    const startProfilingBtn = document.getElementById('startProfilingBtn');
    const suggestionForm = document.getElementById('suggestionForm');
    
    // Show the suggestion form when the start profiling button is clicked
    if (startProfilingBtn) {
        startProfilingBtn.addEventListener('click', function() {
            document.querySelector('.suggestion-intro').style.display = 'none';
            suggestionForm.style.display = 'block';
        });
    }
    
    // Enable/disable dropdown based on checkbox selection
    const jewelryCheckboxes = document.querySelectorAll('input[name="jewelry"]');
    
    jewelryCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', function() {
            const styleDropdown = document.getElementById(`${this.id}Style`);
            styleDropdown.disabled = !this.checked;
            
            // Reset dropdown when unchecked
            if(!this.checked) {
                styleDropdown.value = '';
            }
        });
    });
    
    // Image preview when file is selected
    faceImageInput.addEventListener('change', function() {
        const file = this.files[0];
        if(file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                imagePreview.src = e.target.result;
                imagePreview.style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    });
    
    // Sample product database - in a real app, this would come from a server
    const productDatabase = [
        {
            id: 1,
            name: "Pearl Drop Earrings",
            price: 129.99,
            image: "https://placehold.co/200x200/e8c3c3/ffffff?text=Pearl+Drop+Earrings",
            type: "earrings",
            style: "drop",
            faceShapes: ["oval", "heart", "round"],
            skinTones: ["fair", "light", "medium"],
            occasions: ["wedding", "party"]
        },
        {
            id: 4,
            name: "Silver Hoop Earrings",
            price: 89.99,
            image: "https://placehold.co/200x200/d9d9d9/000000?text=Hoop+Earrings",
            type: "earrings",
            style: "hoop",
            faceShapes: ["square", "round", "oval"],
            skinTones: ["all"],
            occasions: ["daily", "office", "party"]
        },
        {
            id: 3,
            name: "Gold Chain Necklace",
            price: 179.99,
            image: "https://placehold.co/200x200/e8d9c3/000000?text=Gold+Necklace",
            type: "necklace",
            style: "gold",
            neckShapes: ["slim", "average"],
            skinTones: ["medium", "olive", "tan", "dark"],
            occasions: ["daily", "office"]
        },
        {
            id: 5,
            name: "Ruby Pendant Necklace",
            price: 249.99,
            image: "https://placehold.co/200x200/e8c3c3/ffffff?text=Ruby+Necklace",
            type: "necklace",
            style: "pendant",
            neckShapes: ["all"],
            skinTones: ["fair", "light", "medium"],
            occasions: ["wedding", "party"]
        },
        {
            id: 6,
            name: "Sapphire Stud Earrings",
            price: 159.99,
            image: "https://placehold.co/200x200/c3c3e8/ffffff?text=Sapphire+Earrings",
            type: "earrings",
            style: "stud",
            faceShapes: ["all"],
            skinTones: ["fair", "light", "medium", "olive"],
            occasions: ["daily", "office", "wedding"]
        },
        {
            id: 7,
            name: "Pearl Choker Necklace",
            price: 119.99,
            image: "https://placehold.co/200x200/e8e8e8/000000?text=Pearl+Choker",
            type: "necklace",
            style: "choker",
            neckShapes: ["slim", "average"],
            skinTones: ["fair", "light", "medium"],
            occasions: ["wedding", "party"]
        }
    ];
    
    // Function to get recommendations based on form inputs
    function getRecommendations(formData) {
        // Filter products based on form criteria
        return productDatabase.filter(product => {
            let matchScore = 0;
            let criteriaCount = 0;
            
            // Check jewelry type match
            if (formData.jewelryTypes.length > 0) {
                criteriaCount++;
                if (formData.jewelryTypes.includes(product.type)) {
                    matchScore++;
                }
            }
            
            // Check jewelry style match
            if (formData.jewelryStyles[product.type]) {
                criteriaCount++;
                if (product.style === formData.jewelryStyles[product.type]) {
                    matchScore++;
                }
            }
            
            // Check face shape compatibility
            if (formData.faceShape && product.faceShapes) {
                criteriaCount++;
                if (product.faceShapes.includes(formData.faceShape) || product.faceShapes.includes("all")) {
                    matchScore++;
                }
            }
            
            // Check skin tone compatibility
            if (formData.skinTone && product.skinTones) {
                criteriaCount++;
                if (product.skinTones.includes(formData.skinTone) || product.skinTones.includes("all")) {
                    matchScore++;
                }
            }
            
            // Check neck shape compatibility
            if (formData.neckShape && product.neckShapes) {
                criteriaCount++;
                if (product.neckShapes.includes(formData.neckShape) || product.neckShapes.includes("all")) {
                    matchScore++;
                }
            }
            
            // Check occasion match
            if (formData.occasion && product.occasions) {
                criteriaCount++;
                if (product.occasions.includes(formData.occasion)) {
                    matchScore++;
                }
            }
            
            // Product must match at least one criterion if criteria were specified
            return criteriaCount > 0 ? matchScore > 0 : true;
        });
    }
    
    // Form submission
    jewelryForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Collect form data
        const formData = {
            faceShape: document.querySelector('input[name="faceShape"]:checked')?.value,
            skinTone: document.querySelector('input[name="skinTone"]:checked')?.value,
            neckShape: document.querySelector('input[name="neckShape"]:checked')?.value,
            occasion: document.querySelector('input[name="occasion"]:checked')?.value,
            dressType: document.getElementById('dressType').value,
            dressColor: document.getElementById('dressColor').value,
            jewelryTypes: [],
            jewelryStyles: {}
        };
        
        // Collect selected jewelry types and styles
        jewelryCheckboxes.forEach(checkbox => {
            if (checkbox.checked) {
                formData.jewelryTypes.push(checkbox.value);
                const styleDropdown = document.getElementById(`${checkbox.id}Style`);
                if (styleDropdown.value) {
                    formData.jewelryStyles[checkbox.value] = styleDropdown.value;
                }
            }
        });
        
        // Show loading state
        const loadingMessage = document.createElement('p');
        loadingMessage.textContent = 'Finding the perfect jewelry for you...';
        loadingMessage.className = 'loading-message';
        
        const submitBtn = this.querySelector('.submit-btn');
        submitBtn.disabled = true;
        submitBtn.insertAdjacentElement('afterend', loadingMessage);
        
        // Simulate API call delay
        setTimeout(() => {
            // Get recommendations based on form data
            const recommendations = getRecommendations(formData);
            
            // Display recommendations
            displayRecommendations(recommendations);
            resultContainer.style.display = 'block';
            
            // Remove loading message and enable button
            loadingMessage.remove();
            submitBtn.disabled = false;
            
            // Scroll to results
            resultContainer.scrollIntoView({ behavior: 'smooth' });
        }, 1500);
    });
    
    // Function to display product recommendations
    function displayRecommendations(products) {
        if (products.length === 0) {
            recommendedProducts.innerHTML = '<p class="no-results">No products match your criteria. Try changing your selections.</p>';
            return;
        }
        
        let productsHTML = '';
        
        products.forEach(product => {
            productsHTML += `
                <div class="product-card">
                    <img src="${product.image}" alt="${product.name}" class="product-image">
                    <div class="product-details">
                        <div class="product-title">${product.name}</div>
                        <div class="product-price">$${product.price.toFixed(2)}</div>
                        <button class="add-to-cart" data-product-id="${product.id}">Add to Cart</button>
                    </div>
                </div>
            `;
        });
        
        recommendedProducts.innerHTML = productsHTML;
        
        // Add event listeners to add to cart buttons
        document.querySelectorAll('.add-to-cart').forEach(button => {
            button.addEventListener('click', function() {
                const productId = parseInt(this.getAttribute('data-product-id'));
                const product = products.find(p => p.id === productId);
                
                if (product) {
                    addToCart({
                        name: product.name,
                        price: product.price,
                        image: product.image
                    });
                    
                    // Notify user
                    const notification = document.createElement('div');
                    notification.className = 'notification';
                    notification.textContent = 'Item added to cart!';
                    document.body.appendChild(notification);
                    
                    // Remove notification after delay
                    setTimeout(() => {
                        notification.remove();
                    }, 3000);
                }
            });
        });
    }
    
    // Add CSS for notifications if not already present
    if (!document.getElementById('notificationStyles')) {
        const styleElement = document.createElement('style');
        styleElement.id = 'notificationStyles';
        styleElement.textContent = `
            .notification {
                position: fixed;
                bottom: 20px;
                right: 20px;
                background-color: #b08d57;
                color: white;
                padding: 15px 25px;
                border-radius: 5px;
                box-shadow: 0 3px 10px rgba(0,0,0,0.2);
                z-index: 1000;
                animation: fadeInOut 3s;
            }
            
            @keyframes fadeInOut {
                0% { opacity: 0; transform: translateY(20px); }
                10% { opacity: 1; transform: translateY(0); }
                90% { opacity: 1; transform: translateY(0); }
                100% { opacity: 0; transform: translateY(-20px); }
            }
            
            .loading-message {
                margin-top: 15px;
                text-align: center;
                font-style: italic;
                color: #777;
            }
            
            .no-results {
                text-align: center;
                padding: 20px;
                color: #777;
                font-style: italic;
            }
        `;
        document.head.appendChild(styleElement);
    }
});