import os
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import colorsys

# Ensure the directories exist
directories = [
    'img/face_shapes',
    'img/skin_tones',
    'img/neck_shapes', 
    'img/occasions',
    'img/products'
]

for directory in directories:
    os.makedirs(os.path.join('static', directory), exist_ok=True)

def create_icon(filename, text, bg_color=(200, 200, 200), text_color=(0, 0, 0), size=(100, 100)):
    """Create a simple icon with text."""
    img = Image.new('RGB', size, color=bg_color)
    draw = ImageDraw.Draw(img)
    
    # Try to use a system font, fallback to default if not available
    try:
        font = ImageFont.truetype("arial.ttf", 20)
    except IOError:
        font = ImageFont.load_default()
    
    # Draw text in the center
    text_width, text_height = draw.textsize(text, font=font) if hasattr(draw, 'textsize') else (30, 20)
    position = ((size[0] - text_width) // 2, (size[1] - text_height) // 2)
    draw.text(position, text, fill=text_color, font=font)
    
    # Save the image
    img.save(filename)
    print(f"Created {filename}")

# Create face shape icons
face_shapes = ['diamond', 'square', 'round', 'heart', 'oval', 'oblong', 'triangle']
for shape in face_shapes:
    create_icon(
        f'static/img/face_shapes/face_{shape}.png',
        shape.capitalize(),
        bg_color=(230, 210, 200)
    )

# Create skin tone icons with appropriate colors
skin_tones = [
    ('fair', (255, 236, 214)),
    ('light', (241, 212, 184)),
    ('medium', (225, 184, 153)),
    ('olive', (198, 156, 109)),
    ('tan', (166, 123, 91)),
    ('dark', (101, 67, 53))
]

for tone_name, color in skin_tones:
    # Make text color black or white depending on background brightness
    brightness = sum(color) / (3 * 255)
    text_color = (0, 0, 0) if brightness > 0.5 else (255, 255, 255)
    
    create_icon(
        f'static/img/skin_tones/skin_{tone_name}.png',
        tone_name.capitalize(),
        bg_color=color,
        text_color=text_color
    )

# Create neck shape icons
neck_shapes = ['slim', 'average', 'broad']
for shape in neck_shapes:
    create_icon(
        f'static/img/neck_shapes/neck_{shape}.png',
        shape.capitalize(),
        bg_color=(200, 220, 240)
    )

# Create occasion icons
occasions = ['daily', 'wedding', 'party', 'office']
occasion_colors = {
    'daily': (180, 230, 180),  # Light green
    'wedding': (255, 230, 240),  # Light pink
    'party': (230, 180, 250),  # Light purple
    'office': (200, 200, 220)   # Light blue-gray
}

for occasion in occasions:
    create_icon(
        f'static/img/occasions/occasion_{occasion}.png',
        occasion.capitalize(),
        bg_color=occasion_colors.get(occasion, (200, 200, 200))
    )

# Create product images
products = [
    'pearl_earrings',
    'diamond_bracelet',
    'gold_necklace',
    'hoop_earrings',
    'ruby_necklace',
    'sapphire_earrings',
    'pearl_choker',
    'solitaire_ring'
]

# Generate different colors for products
for i, product in enumerate(products):
    # Generate a color based on position in the list
    hue = i / len(products)
    r, g, b = [int(c * 255) for c in colorsys.hsv_to_rgb(hue, 0.7, 0.95)]
    
    # Create a slightly larger image for products
    create_icon(
        f'static/img/products/{product}.jpg',
        product.replace('_', ' ').title(),
        bg_color=(r, g, b),
        text_color=(255, 255, 255),
        size=(200, 200)
    )

print("All placeholder images created successfully!") 