import unittest
import os
import sys
import json
import io
from unittest.mock import patch, MagicMock

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import flask_app
import numpy as np

class TestFlaskApp(unittest.TestCase):
    """Integration tests for Flask application"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.app = flask_app.app
        self.app.config['TESTING'] = True
        self.client = self.app.test_client()
        
        # Ensure test directory exists
        os.makedirs('static/test', exist_ok=True)
        # Create a test image file
        with open('static/test/item10.png', 'wb') as f:
            f.write(b'test image content')

    def tearDown(self):
        """Clean up after tests"""
        # Remove test file if it exists
        if os.path.exists('static/test/item10.png'):
            os.remove('static/test/item10.png')
        if os.path.exists('static/test'):
            os.rmdir('static/test')
    
    def test_index_route(self):
        """Test the index route"""
        with patch('flask.render_template') as mock_render:
            mock_render.return_value = "rendered template"
            response = self.client.get('/')
            self.assertEqual(response.status_code, 200)
            mock_render.assert_called_once_with('index.html')
    
    def test_api_docs_route(self):
        """Test the API documentation route"""
        with patch('flask.render_template') as mock_render:
            mock_render.return_value = "rendered template"
            response = self.client.get('/api/docs')
            self.assertEqual(response.status_code, 200)
            # Check that we're passing endpoints to the template
            args, kwargs = mock_render.call_args
            self.assertEqual(args[0], 'api_docs.html')
            self.assertIn('endpoints', kwargs)
    
    def test_tryon_route_valid(self):
        """Test the tryon route with valid path"""
        with patch('flask.render_template') as mock_render, \
             patch('os.path.exists') as mock_exists:
            
            mock_exists.return_value = True
            mock_render.return_value = "rendered template"
            
            response = self.client.get('/tryon/test,item10.png')
            
            self.assertEqual(response.status_code, 200)
            mock_render.assert_called_once_with('checkout.html', file_path='test/item10.png')
    
    def test_tryon_route_invalid_path(self):
        """Test the tryon route with invalid path"""
        with patch('flask.render_template') as mock_render, \
             patch('os.path.exists') as mock_exists:
            
            mock_exists.return_value = False
            mock_render.return_value = "rendered template"
            
            response = self.client.get('/tryon/test,nonexistent.png')
            
            self.assertEqual(response.status_code, 404)
            mock_render.assert_called_once_with('error.html', error='File not found')
    
    def test_tryon_route_path_traversal(self):
        """Test the tryon route with path traversal attempt"""
        with patch('flask.render_template') as mock_render:
            mock_render.return_value = "rendered template"
            
            response = self.client.get('/tryon/../../etc/passwd')
            
            self.assertEqual(response.status_code, 403)
            mock_render.assert_called_once_with('error.html', error='Invalid file path')
    
    @patch('virtual_trial.process_frame')
    def test_upload_frame_valid(self, mock_process_frame):
        """Test the upload_frame route with valid data"""
        # Mock the virtual_trial.process_frame function
        mock_frame = np.zeros((100, 100, 3), dtype=np.uint8)
        mock_process_frame.return_value = mock_frame
        
        # Create test data
        data = {
            'json_data': json.dumps({'file_path': 'test/item10.png'})
        }
        
        # Create a test image file
        test_image = io.BytesIO(b'fake image content')
        
        # Make the request
        response = self.client.post(
            '/upload_frame',
            data=dict(data, frame=(test_image, 'test.jpg')),
            content_type='multipart/form-data'
        )
        
        # Check the response
        self.assertEqual(response.status_code, 200)
        response_data = json.loads(response.data)
        self.assertIn('image', response_data)
    
    def test_upload_frame_no_frame(self):
        """Test the upload_frame route with no frame"""
        # Create test data without a frame
        data = {
            'json_data': json.dumps({'file_path': 'test/item10.png'})
        }
        
        # Make the request
        response = self.client.post(
            '/upload_frame',
            data=data,
            content_type='multipart/form-data'
        )
        
        # Check the response
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertEqual(response_data['error'], 'No frame part')
    
    def test_upload_frame_no_json_data(self):
        """Test the upload_frame route with no JSON data"""
        # Create test data without JSON
        test_image = io.BytesIO(b'fake image content')
        
        # Make the request
        response = self.client.post(
            '/upload_frame',
            data={'frame': (test_image, 'test.jpg')},
            content_type='multipart/form-data'
        )
        
        # Check the response
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertEqual(response_data['error'], 'No JSON data')
    
    def test_upload_frame_invalid_json(self):
        """Test the upload_frame route with invalid JSON"""
        # Create test data with invalid JSON
        data = {
            'json_data': 'not valid json'
        }
        
        # Create a test image file
        test_image = io.BytesIO(b'fake image content')
        
        # Make the request
        response = self.client.post(
            '/upload_frame',
            data=dict(data, frame=(test_image, 'test.jpg')),
            content_type='multipart/form-data'
        )
        
        # Check the response
        self.assertEqual(response.status_code, 400)
        response_data = json.loads(response.data)
        self.assertEqual(response_data['error'], 'Invalid JSON data')
    
    def test_upload_frame_invalid_file_path(self):
        """Test the upload_frame route with invalid file path"""
        # Create test data with non-existent file path
        data = {
            'json_data': json.dumps({'file_path': 'nonexistent/path.png'})
        }
        
        # Create a test image file
        test_image = io.BytesIO(b'fake image content')
        
        # Make the request
        response = self.client.post(
            '/upload_frame',
            data=dict(data, frame=(test_image, 'test.jpg')),
            content_type='multipart/form-data'
        )
        
        # Check the response
        self.assertEqual(response.status_code, 404)
        response_data = json.loads(response.data)
        self.assertIn('File not found', response_data['error'])
    
    @patch('virtual_trial.process_frame')
    def test_upload_frame_process_error(self, mock_process_frame):
        """Test handling when process_frame returns None"""
        # Mock process_frame to return None (no face detected)
        mock_process_frame.return_value = None
        
        # Create test data
        data = {
            'json_data': json.dumps({'file_path': 'test/item10.png'})
        }
        
        # Create a test image file
        test_image = io.BytesIO(b'fake image content')
        
        # Make the request
        response = self.client.post(
            '/upload_frame',
            data=dict(data, frame=(test_image, 'test.jpg')),
            content_type='multipart/form-data'
        )
        
        # Check the response
        self.assertEqual(response.status_code, 404)
        response_data = json.loads(response.data)
        self.assertEqual(response_data['error'], 'No face detected or no sprite applied')
    
    def test_error_handlers(self):
        """Test error handlers (404, 500)"""
        # Test 404 handler
        with patch('flask.render_template') as mock_render:
            mock_render.return_value = "rendered template"
            
            response = self.client.get('/nonexistent_page')
            
            self.assertEqual(response.status_code, 404)
            mock_render.assert_called_with('error.html', error='Page not found')

if __name__ == '__main__':
    unittest.main() 