import unittest
import os
import sys
import cv2
import numpy as np
from unittest.mock import patch, MagicMock

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import virtual_trial
from virtual_trial import VirtualDressingRoom

class TestVirtualDressingRoom(unittest.TestCase):
    """Test cases for the VirtualDressingRoom class"""
    
    def setUp(self):
        """Set up test fixtures"""
        self.dresser = VirtualDressingRoom()
        # Create a simple test image (50x50 blank image)
        self.test_image = np.zeros((50, 50, 4), dtype=np.uint8)
        self.test_image[:, :, 3] = 255  # Set alpha channel
        
        # Create a simple frame (100x100 blank image)
        self.frame = np.zeros((100, 100, 3), dtype=np.uint8)
    
    def test_put_sprite(self):
        """Test the put_sprite method"""
        self.dresser.put_sprite(1, 2)
        self.assertEqual(self.dresser.sprites[1], 1)
        self.assertEqual(self.dresser.active_images[1], 2)
        
        # Test with sprite off
        self.dresser.sprites[1] = 0
        self.dresser.put_sprite(1, 3)
        self.assertEqual(self.dresser.sprites[1], 1)
        self.assertEqual(self.dresser.active_images[1], 3)
    
    def test_draw_sprite(self):
        """Test the draw_sprite method"""
        # Test with valid inputs
        result = self.dresser.draw_sprite(self.frame.copy(), self.test_image, 10, 10)
        self.assertIsNotNone(result)
        
        # Test with None frame
        result = self.dresser.draw_sprite(None, self.test_image, 10, 10)
        self.assertIsNone(result)
        
        # Test with None sprite
        result = self.dresser.draw_sprite(self.frame.copy(), None, 10, 10)
        self.assertIsNotNone(result)  # Should return original frame
    
    def test_adjust_sprite2head(self):
        """Test the adjust_sprite2head method"""
        # Test with valid inputs
        sprite, y_pos = self.dresser.adjust_sprite2head(self.test_image, 100, 50)
        self.assertIsNotNone(sprite)
        self.assertGreaterEqual(y_pos, 0)
        
        # Test with ontop=False
        sprite, y_pos = self.dresser.adjust_sprite2head(self.test_image, 100, 50, ontop=False)
        self.assertEqual(y_pos, 50)
        
        # Test with negative y_orig
        sprite, y_pos = self.dresser.adjust_sprite2head(self.test_image, 100, 10, ontop=True)
        self.assertEqual(y_pos, 0)
        
        # Test exception handling
        with self.assertRaises(Exception):
            self.dresser.adjust_sprite2head(None, 100, 50)
    
    def test_calculate_inclination(self):
        """Test the calculate_inclination method"""
        point1 = np.array([0, 0])
        point2 = np.array([10, 10])
        incl = self.dresser.calculate_inclination(point1, point2)
        self.assertEqual(incl, 45.0)
        
        point1 = np.array([0, 0])
        point2 = np.array([10, 0])
        incl = self.dresser.calculate_inclination(point1, point2)
        self.assertEqual(incl, 0.0)
    
    def test_calculate_boundbox(self):
        """Test the calculate_boundbox method"""
        points = np.array([
            [10, 20],
            [30, 40],
            [50, 60]
        ])
        x, y, w, h = self.dresser.calculate_boundbox(points)
        self.assertEqual(x, 10)
        self.assertEqual(y, 20)
        self.assertEqual(w, 40)
        self.assertEqual(h, 40)
    
    def test_get_category_number(self):
        """Test the get_category_number method"""
        # Test valid category extraction
        category = self.dresser.get_category_number("static/images/item20.png")
        self.assertEqual(category, 2)
        
        category = self.dresser.get_category_number("static/images/item31.png")
        self.assertEqual(category, 3)
        
        # Test invalid path
        category = self.dresser.get_category_number("")
        self.assertEqual(category, -1)
    
    def test_get_k(self):
        """Test the get_k method"""
        # Test valid k extraction
        k = self.dresser.get_k("static/images/item21.png")
        self.assertEqual(k, 1)
        
        k = self.dresser.get_k("static/images/item35.png")
        self.assertEqual(k, 5)
        
        # Test invalid path
        k = self.dresser.get_k("")
        self.assertEqual(k, -1)
    
    @patch('os.path.exists')
    @patch('dlib.shape_predictor')
    def test_detect_faces(self, mock_predictor, mock_exists):
        """Test the detect_faces method"""
        mock_exists.return_value = True
        mock_predictor.return_value = MagicMock()
        
        # Mock face detector
        self.dresser.face_detector = MagicMock()
        self.dresser.face_detector.return_value = ["face1", "face2"]
        
        faces, predictor, gray = self.dresser.detect_faces(self.frame)
        self.assertEqual(len(faces), 2)
        self.assertIsNotNone(gray)
        
        # Test when model path doesn't exist
        mock_exists.return_value = False
        with self.assertRaises(FileNotFoundError):
            self.dresser.detect_faces(self.frame)
    
    @patch('virtual_trial.VirtualDressingRoom.initialize_images_and_photos')
    @patch('virtual_trial.VirtualDressingRoom.detect_faces')
    @patch('virtual_trial.VirtualDressingRoom._process_face')
    @patch('os.path.exists')
    def test_process_frame(self, mock_exists, mock_process_face, mock_detect_faces, mock_init):
        """Test the process_frame method"""
        # Setup mocks
        mock_exists.return_value = True
        mock_face = MagicMock()
        mock_predictor = MagicMock()
        mock_detect_faces.return_value = (["face1"], mock_predictor, np.zeros((100, 100), dtype=np.uint8))
        mock_process_face.return_value = True
        
        # Test successful processing
        result = self.dresser.process_frame(self.frame, "static/images/item10.png")
        self.assertIsNotNone(result)
        
        # Test when no faces detected
        mock_detect_faces.return_value = ([], mock_predictor, np.zeros((100, 100), dtype=np.uint8))
        result = self.dresser.process_frame(self.frame, "static/images/item10.png")
        self.assertIsNone(result)
        
        # Test with invalid frame
        result = self.dresser.process_frame(None, "static/images/item10.png")
        self.assertIsNone(result)
        
        # Test with invalid file path
        result = self.dresser.process_frame(self.frame, "")
        self.assertIsNone(result)
        
        # Test when file doesn't exist
        mock_exists.return_value = False
        result = self.dresser.process_frame(self.frame, "static/images/nonexistent.png")
        self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main() 