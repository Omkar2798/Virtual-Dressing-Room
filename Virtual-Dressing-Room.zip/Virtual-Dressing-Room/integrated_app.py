from flask import Flask, render_template, Response, request, jsonify
from flask_socketio import SocketIO, emit
import base64
import numpy as np
import cv2
import json
import virtual_trial
import os
import logging
import re
from functools import wraps
from werkzeug.utils import secure_filename
from typing import Dict, Any, Tuple, Optional, Union, List

# Configure logging
logging.basicConfig(level=logging.INFO, 
                   format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger('virtual_dressing_room_app')

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max upload size
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg'}

# Ensure upload directory exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Initialize SocketIO with eventlet async mode
socketio = SocketIO(app, async_mode='eventlet')

def allowed_file(filename: str) -> bool:
    """
    Check if a file has an allowed extension
    
    Args:
        filename: The filename to check
        
    Returns:
        True if file extension is allowed, False otherwise
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def secure_path(path: str) -> str:
    """
    Make a file path secure by removing path traversal characters
    
    Args:
        path: The path to secure
        
    Returns:
        Secured path string
    """
    # Remove any path traversal attempts
    path = re.sub(r'\.\.', '', path)
    # Replace any backslashes with forward slashes
    path = path.replace('\\', '/')
    # Remove any double slashes
    path = re.sub(r'//+', '/', path)
    # Remove leading slash if present
    path = path.lstrip('/')
    
    return path

# Main Routes

@app.route('/')
def index():
    """
    Render the main jewelry brand page
    """
    return render_template('jewelry_brand.html')

@app.route('/original')
def original_index():
    """
    Return the original virtual dressing room index page
    """
    return render_template('index.html')

@app.route('/checkout')
def checkout():
    """
    Render the checkout page
    """
    return render_template('jewelry_checkout.html')

# Virtual Dressing Room Routes

@app.route('/tryon/<path:file_path>', methods=['POST', 'GET'])
def tryon(file_path: str) -> Union[str, Tuple[str, int]]:
    """
    Render the checkout page for trying on a specific item
    
    Args:
        file_path: Path to the item to try on
        
    Returns:
        Rendered HTML template or error page
    """
    try:
        logger.info(f"Received request for file_path: {file_path}")
        
        if not file_path:
            logger.error("Empty file path provided")
            return render_template("error.html", error="Invalid file path provided"), 400
            
        # Sanitize file path to prevent directory traversal
        file_path = secure_path(file_path)
        logger.info(f"Sanitized file_path: {file_path}")
        
        # Validate if the file exists in the allowed directory
        real_path = os.path.join('static', file_path)
        real_path = os.path.normpath(real_path)
        
        logger.info(f"Real path: {real_path}")
        logger.info(f"File exists: {os.path.exists(real_path)}")
        
        # Ensure the path is still in the static directory
        static_dir = os.path.abspath(os.path.join(os.getcwd(), 'static'))
        real_abs_path = os.path.abspath(real_path)
        
        logger.info(f"Static directory: {static_dir}")
        logger.info(f"Absolute real path: {real_abs_path}")
        logger.info(f"Path in static directory: {real_abs_path.startswith(static_dir)}")
        
        if not real_abs_path.startswith(static_dir):
            logger.error(f"Path traversal attempt: {real_path}")
            return render_template("error.html", error="Invalid file path"), 403
            
        if not os.path.exists(real_path):
            logger.error(f"File not found: {real_path}")
            return render_template("error.html", error=f"File not found: {real_path}"), 404
            
        logger.info(f"Rendering checkout.html with file_path={file_path}")
        return render_template("checkout.html", file_path=file_path)
    except Exception as e:
        logger.error(f"Error in tryon route: {str(e)}")
        return render_template("error.html", error=f"An unexpected error occurred: {str(e)}"), 500

@app.route('/upload_frame', methods=['POST'])
def process_frame_upload() -> Tuple[Dict[str, Any], int]:
    """
    Process a frame upload with a sprite overlay
    
    Expects:
        - 'frame': An image file
        - 'json_data': JSON string containing 'file_path'
        
    Returns:
        JSON response with processed image or error message
    """
    try:
        # Validate input
        if 'frame' not in request.files:
            logger.error("No frame part in the request")
            return jsonify({'error': 'No frame part'}), 400
            
        if 'json_data' not in request.form:
            logger.error("No JSON data in the request")
            return jsonify({'error': 'No JSON data'}), 400
            
        file = request.files['frame']
        if not file:
            logger.error("Empty file uploaded")
            return jsonify({'error': 'Empty file'}), 400
            
        # Validate file type
        if file.filename and not allowed_file(file.filename):
            logger.error(f"Invalid file type: {file.filename}")
            return jsonify({'error': 'Invalid file type. Only PNG and JPEG allowed.'}), 400
            
        json_data = request.form['json_data']
        
        try:
            data = json.loads(json_data)
        except json.JSONDecodeError:
            logger.error("Invalid JSON data")
            return jsonify({'error': 'Invalid JSON data'}), 400
            
        if 'file_path' not in data:
            logger.error("No file_path in JSON data")
            return jsonify({'error': 'No file_path in data'}), 400
            
        file_path = data['file_path']
        
        # Debug the file path
        logger.info(f"Received file path in upload_frame: {file_path}")
        
        # Secure the file path
        # Check if file_path already starts with 'static/' and remove it if it does
        if file_path.startswith('static/'):
            file_path = file_path[7:]  # Remove 'static/' prefix
            
        file_path = secure_path(file_path)
        logger.info(f"Secured file path: {file_path}")
        
        # Validate file path
        real_path = os.path.join('static', file_path)
        real_path = os.path.normpath(real_path)
        logger.info(f"Normalized real path: {real_path}")
        logger.info(f"File exists check: {os.path.exists(real_path)}")
        
        # Ensure the path is still in the static directory
        static_dir = os.path.abspath(os.path.join(os.getcwd(), 'static'))
        real_abs_path = os.path.abspath(real_path)
        logger.info(f"Static directory: {static_dir}")
        logger.info(f"Absolute real path: {real_abs_path}")
        logger.info(f"Path in static directory: {real_abs_path.startswith(static_dir)}")
        
        if not real_abs_path.startswith(static_dir):
            logger.error(f"Path traversal attempt: {real_path}")
            return jsonify({'error': 'Invalid file path'}), 403
            
        if not os.path.exists(real_path):
            logger.error(f"File not found: {real_path}")
            return jsonify({'error': f'File not found: {real_path}'}), 404
        
        # Read the uploaded frame
        filestr = file.read()
        if not filestr:
            logger.error("Empty frame data")
            return jsonify({'error': 'Empty frame data'}), 400
            
        npimg = np.frombuffer(filestr, np.uint8)
        frame = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
        
        if frame is None:
            logger.error("Failed to decode frame")
            return jsonify({'error': 'Failed to decode frame'}), 400

        # Process the frame
        processed_frame = virtual_trial.process_frame(frame, real_path)
        if processed_frame is not None:
            ret, jpeg = cv2.imencode('.jpg', processed_frame)
            if ret:
                return jsonify({'image': base64.b64encode(jpeg.tobytes()).decode('utf-8')})
            else:
                logger.error("Failed to encode processed frame")
                return jsonify({'error': 'Failed to encode processed frame'}), 500
        else:
            logger.info("No face detected or no sprite applied")
            return jsonify({'error': 'No face detected or no sprite applied'}), 404
    except FileNotFoundError as e:
        logger.error(f"File not found: {str(e)}")
        return jsonify({'error': f'File not found: {str(e)}'}), 404
    except ValueError as e:
        logger.error(f"Value error: {str(e)}")
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logger.error(f"Unexpected error in process_frame_upload: {str(e)}")
        return jsonify({'error': f'An unexpected error occurred during processing: {str(e)}'}), 500

# WebSocket Handlers

@socketio.on('connect')
def handle_connect():
    """Handle new WebSocket connections"""
    logger.info(f"Client connected: {request.sid}")

@socketio.on('disconnect')
def handle_disconnect():
    """Handle client disconnections"""
    logger.info(f"Client disconnected: {request.sid}")

@socketio.on('stream_frame')
def handle_stream_frame(data):
    """Process a frame received over WebSocket"""
    try:
        # Extract data
        # Expecting data like: {'frame': 'data:image/jpeg;base64,...', 'file_path': 'path/to/item.png'}
        base64_frame = data.get('frame')
        file_path = data.get('file_path')

        if not base64_frame or not file_path:
            emit('stream_error', {'error': 'Missing frame or file_path'})
            return

        # Debug the file path
        logger.info(f"Received file path: {file_path}")

        # Decode the base64 frame
        try:
            # Remove the header ('data:image/jpeg;base64,')
            if ',' in base64_frame:
                img_data = base64.b64decode(base64_frame.split(',')[1])
            else:
                img_data = base64.b64decode(base64_frame)
                
            npimg = np.frombuffer(img_data, np.uint8)
            frame = cv2.imdecode(npimg, cv2.IMREAD_COLOR)
            if frame is None:
                raise ValueError("Failed to decode frame")
        except Exception as e:
            logger.error(f"Frame decoding error: {str(e)}")
            emit('stream_error', {'error': 'Invalid frame data'})
            return

        # Secure and validate file_path
        # Check if file_path already starts with 'static/' and remove it if it does
        original_file_path = file_path
        if file_path.startswith('static/'):
            file_path = file_path[7:]  # Remove 'static/' prefix
            logger.info(f"Removed 'static/' prefix from path: {original_file_path} -> {file_path}")
            
        secure_file_path = secure_path(file_path)
        logger.info(f"Secured file path: {secure_file_path}")
        
        real_path = os.path.join('static', secure_file_path)
        real_path = os.path.normpath(real_path)
        logger.info(f"Normalized real path: {real_path}")
        logger.info(f"File exists check: {os.path.exists(real_path)}")
        
        # Ensure the path is still in the static directory
        static_dir = os.path.abspath(os.path.join(os.getcwd(), 'static'))
        real_abs_path = os.path.abspath(real_path)
        logger.info(f"Static directory: {static_dir}")
        logger.info(f"Absolute real path: {real_abs_path}")
        logger.info(f"Path in static directory: {real_abs_path.startswith(static_dir)}")
        
        file_error = None
        
        if not real_abs_path.startswith(static_dir):
            logger.error(f"Path traversal attempt: {real_path}")
            file_error = "Invalid item file path"
            
        elif not os.path.exists(real_path):
            logger.error(f"File not found: {real_path}")
            file_error = f"File not found: {real_path}"

        # Process the frame if there's no file error, otherwise just return the original frame
        if file_error is None:
            processed_frame = virtual_trial.process_frame(frame, real_path)
        else:
            # Emit error but don't return - we'll still send the original frame
            emit('stream_error', {'error': file_error})
            processed_frame = frame  # Use original frame instead of None
        
        # Always send back a frame, whether processed or original
        ret, buffer = cv2.imencode('.jpg', processed_frame, [cv2.IMWRITE_JPEG_QUALITY, 80])  # Compress slightly
        if ret:
            encoded_image = base64.b64encode(buffer).decode('utf-8')
            # Send the frame back to the specific client
            emit('processed_frame', {'image': 'data:image/jpeg;base64,' + encoded_image})
        else:
            logger.error("Failed to encode frame")
            emit('stream_error', {'error': 'Failed to encode result'})

    except Exception as e:
        logger.error(f"Error processing stream frame: {str(e)}")
        emit('stream_error', {'error': f'Server processing error: {str(e)}'})

# Error Handlers

@app.errorhandler(404)
def page_not_found(e) -> Tuple[str, int]:
    """
    Handle 404 errors
    
    Args:
        e: The error object
        
    Returns:
        Error template with 404 status code
    """
    logger.error(f"404 error: {str(e)}")
    return render_template('error.html', error="Page not found"), 404

@app.errorhandler(500)
def internal_server_error(e) -> Tuple[str, int]:
    """
    Handle 500 errors
    
    Args:
        e: The error object
        
    Returns:
        Error template with 500 status code
    """
    logger.error(f"500 error: {str(e)}")
    return render_template('error.html', error="Internal server error"), 500

if __name__ == '__main__':
    logger.info("Starting integrated Virtual Dressing Room + Jewelry Brand application on port 5001")
    socketio.run(app, debug=True, port=5001, host="0.0.0.0") 